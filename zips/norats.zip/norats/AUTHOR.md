# Author Metadata

## Autore

Dott. Sarino Alfonso Grande

## Contatti

- Email: sino.grande@gmail.com
- Sito web: https://sinocloud.it

## Note

Le informazioni autore sono allineate agli altri plugin della famiglia SinoCloud
(Q-Press, SARIAG, Quick CRS Fixer, GeoBridge, GeoCSV Mapper, QGIS Ledger, STAC
Browser, TAF Italia):

- Autore: Dott. Sarino Alfonso Grande
- Email: sino.grande@gmail.com
- Sito Web: sinocloud.it
