"""Report HTML di NoRats per l'amministrazione comunale.

Il report riepiloga lo stato della campagna: postazioni in ritardo di
ispezione, consumo medio delle esche (indicatore dell'attività murina),
avvistamenti recenti e aree a rischio non trattate.
"""
import datetime
import html

NAVY = "#1F3864"

_CSS = f"""
body {{ font-family: 'Liberation Serif', Georgia, serif; margin: 2em auto; max-width: 60em; color: #1a1a1a; }}
h1 {{ color: {NAVY}; text-align: center; }}
h2 {{ color: {NAVY}; border-bottom: 2px solid {NAVY}; padding-bottom: 0.2em; }}
table {{ border-collapse: collapse; width: 100%; margin: 1em 0; }}
th {{ background: {NAVY}; color: white; padding: 0.4em 0.6em; text-align: left; }}
td {{ border: 1px solid {NAVY}; padding: 0.35em 0.6em; }}
p.meta {{ text-align: center; font-style: italic; }}
.warn {{ color: #c62828; font-weight: bold; }}
.ok {{ color: #2e7d32; font-weight: bold; }}
"""


def _to_date(value):
    """Converte QDate/stringa/None in datetime.date (o None)."""
    if value is None or value == "":
        return None
    if isinstance(value, datetime.date):
        return value
    if hasattr(value, "toPyDate"):  # QDate
        date = value.toPyDate()
        return None if date.year <= 1 else date
    try:
        return datetime.date.fromisoformat(str(value)[:10])
    except ValueError:
        return None


def _esc(value):
    if value is None:
        return ""
    return html.escape(str(value))


def _table(headers, rows):
    head = "".join(f"<th>{_esc(h)}</th>" for h in headers)
    body = "".join(
        "<tr>" + "".join(f"<td>{cell}</td>" for cell in row) + "</tr>" for row in rows
    )
    return f"<table><tr>{head}</tr>{body}</table>"


def build_report_html(stations_layer, inspections_layer, sightings_layer, risk_layer,
                      municipality: str = "Comune di Mandatoriccio (CS)") -> str:
    """Costruisce il report HTML a partire dai quattro layer NoRats."""
    today = datetime.date.today()

    stations = list(stations_layer.getFeatures())
    inspections = list(inspections_layer.getFeatures())
    sightings = list(sightings_layer.getFeatures())
    risk_areas = list(risk_layer.getFeatures())

    active = [s for s in stations if s["status"] == "Attiva"]
    overdue_rows = []
    for station in active:
        last = _to_date(station["last_inspection"])
        days = (today - last).days if last else None
        if last is None or days > 30:
            state = "MAI ISPEZIONATA" if last is None else f"{days} giorni fa"
            overdue_rows.append(
                [
                    _esc(station["code"]),
                    _esc(station["location_desc"]),
                    f'<span class="warn">{_esc(state)}</span>',
                ]
            )

    consumptions = [
        i["consumption_pct"] for i in inspections if i["consumption_pct"] is not None
    ]
    avg_consumption = sum(consumptions) / len(consumptions) if consumptions else 0

    recent_sights = []
    for sight in sightings:
        date = _to_date(sight["sight_date"])
        if date and (today - date).days <= 30:
            recent_sights.append(
                [
                    _esc(date.strftime("%d/%m/%Y")),
                    _esc(sight["species"]),
                    _esc(sight["individuals"]),
                    _esc(sight["reporter"]),
                ]
            )

    untreated_rows = []
    for area in risk_areas:
        treated = _to_date(area["last_treatment"])
        if treated is None or (today - treated).days > 90:
            state = "MAI TRATTATA" if treated is None else treated.strftime("%d/%m/%Y")
            untreated_rows.append(
                [
                    _esc(area["name"]),
                    _esc(area["area_type"]),
                    _esc(area["risk_level"]),
                    f'<span class="warn">{_esc(state)}</span>',
                ]
            )

    overview_html = _table(
        ["Indicatore", "Valore"],
        [
            ["Postazioni esca totali", len(stations)],
            ["Postazioni attive", len(active)],
            ["Ispezioni registrate", len(inspections)],
            ["Consumo medio esche", f"{avg_consumption:.0f}%"],
            ["Avvistamenti registrati", len(sightings)],
            ["Aree a rischio censite", len(risk_areas)],
        ],
    )
    overdue_html = (
        _table(["Codice", "Ubicazione", "Ultima ispezione"], overdue_rows)
        if overdue_rows
        else '<p class="ok">Nessuna postazione in ritardo: tutte ispezionate negli ultimi 30 giorni.</p>'
    )
    sights_html = (
        _table(["Data", "Specie", "Esemplari", "Segnalato da"], recent_sights)
        if recent_sights
        else '<p class="ok">Nessun avvistamento negli ultimi 30 giorni.</p>'
    )
    untreated_html = (
        _table(["Area", "Tipologia", "Livello rischio", "Ultimo trattamento"], untreated_rows)
        if untreated_rows
        else '<p class="ok">Tutte le aree a rischio risultano trattate negli ultimi 90 giorni.</p>'
    )

    return f"""<!DOCTYPE html>
<html lang="it"><head><meta charset="utf-8">
<title>Report derattizzazione NoRats</title><style>{_CSS}</style></head>
<body>
<h1>Report campagna di derattizzazione</h1>
<p class="meta">{_esc(municipality)} — generato il {today.strftime('%d/%m/%Y')} con NoRats</p>

<h2>1. Quadro generale</h2>
{overview_html}

<h2>2. Postazioni in ritardo di ispezione (oltre 30 giorni)</h2>
{overdue_html}

<h2>3. Avvistamenti degli ultimi 30 giorni</h2>
{sights_html}

<h2>4. Aree a rischio senza trattamento recente (oltre 90 giorni)</h2>
{untreated_html}

<p class="meta">Documento tecnico di monitoraggio — piano di derattizzazione su base GIS.</p>
</body></html>
"""


def save_report(path: str, **kwargs) -> str:
    """Genera e salva il report; restituisce il percorso scritto."""
    content = build_report_html(**kwargs)
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(content)
    return path
