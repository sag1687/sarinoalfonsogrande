"""Download di dati territoriali per NoRats.

Tre sorgenti, tutte ritagliate sul limite comunale ISTAT:

- **ISTAT**: confini amministrativi generalizzati (zip ufficiale, scaricato
  una sola volta e tenuto in cache nel profilo QGIS);
- **Agenzia delle Entrate**: particelle catastali via WFS INSPIRE
  (``CP:CadastralParcel``), scaricate a tile <= 4 km2 con pausa tra le
  chiamate, deduplicate e rese "mute" (solo poligoni, nessun attributo,
  nessuna vestizione AdE);
- **OpenStreetMap**: strade (``highway=*``) via Overpass API, ritagliate
  esattamente sul limite comunale.

Tutte le funzioni sono senza GUI: ricevono callback ``progress(percent,
message)`` e ``is_canceled()`` così da poter girare in un QgsTask.
Il riferimento per la parte WFS AdE è il plugin "WFS Catasto - download
particelle bbox" di Salvatore Fiandaca (GPL).
"""
import json
import math
import os
import tempfile
import time
import urllib.parse
import urllib.request
import zipfile

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsCoordinateTransformContext,
    QgsFeature,
    QgsField,
    QgsGeometry,
    QgsProject,
    QgsRectangle,
    QgsVectorFileWriter,
    QgsVectorLayer,
)
from qgis.PyQt.QtCore import QMetaType

USER_AGENT = "NoRats-QGIS-Plugin/1.1 (+https://sinocloud.it; info@sinocloud.it)"

ISTAT_YEAR = "2025"
ISTAT_URL = (
    "https://www.istat.it/storage/cartografia/confini_amministrativi/"
    f"generalizzati/{ISTAT_YEAR}/Limiti0101{ISTAT_YEAR}_g.zip"
)
ISTAT_LICENSE = "ISTAT — Confini amministrativi, licenza CC BY 4.0"

ADE_WFS_URL = (
    "https://wfs.cartografia.agenziaentrate.gov.it/inspire/wfs/owfs01.php?"
    "service=WFS&request=GetFeature&version=2.0.0"
    "&typeNames=CP:CadastralParcel"
)
ADE_CRS_AUTHID = "EPSG:6706"  # RDN2008, assi lat/lon
ADE_MAX_TILE_KM2 = 4.0        # soglia di sicurezza del servizio WFS
ADE_PAUSE_S = 1.5             # cortesia verso il server tra una tile e l'altra

OVERPASS_URL = "https://overpass-api.de/api/interpreter"
NOMINATIM_URL = "https://nominatim.openstreetmap.org/search"

LAYER_BOUNDARY = "limite_comunale_istat"
LAYER_PARCELS = "particelle_catastali_ade"
LAYER_ROADS = "strade_osm"


class DownloadError(RuntimeError):
    """Errore di download con messaggio già pronto per l'utente."""


def _noop_progress(percent, message):
    pass


def _never_canceled():
    return False


# ---------------------------------------------------------------- rete

def _ensure_https(url):
    """Whitelist dello schema: solo HTTPS verso gli host noti del plugin.

    Difesa in profondità per gli analizzatori statici (es. Bandit B310):
    ``url`` è sempre costruito da questo modulo a partire dalle costanti
    *_URL sopra, mai da input dell'utente, ma il controllo esplicito
    impedisce comunque l'apertura di schemi imprevisti (``file://`` ecc.).
    """
    if not url.startswith("https://"):
        raise DownloadError(f"Schema URL non consentito (solo https): {url}")
    return url


def _http_get(url, data=None, timeout=180):
    request = urllib.request.Request(
        _ensure_https(url), data=data, headers={"User-Agent": USER_AGENT}
    )
    # Schema già forzato a https da _ensure_https sopra.
    with urllib.request.urlopen(request, timeout=timeout) as response:  # nosec B310
        return response.read()


def _download_to_file(url, dest_path, progress, label):
    request = urllib.request.Request(_ensure_https(url), headers={"User-Agent": USER_AGENT})
    # Schema già forzato a https da _ensure_https sopra.
    with urllib.request.urlopen(request, timeout=300) as response:  # nosec B310
        total = int(response.headers.get("Content-Length") or 0)
        done = 0
        tmp_path = dest_path + ".part"
        with open(tmp_path, "wb") as handle:
            while True:
                chunk = response.read(256 * 1024)
                if not chunk:
                    break
                handle.write(chunk)
                done += len(chunk)
                if total:
                    progress(done * 100 / total, f"{label} ({done // 1048576} MB)")
    os.replace(tmp_path, dest_path)


# ---------------------------------------------------------------- ISTAT

def ensure_istat_zip(cache_dir, progress=_noop_progress):
    """Scarica (una sola volta) lo zip ISTAT dei confini; ritorna il percorso."""
    os.makedirs(cache_dir, exist_ok=True)
    zip_path = os.path.join(cache_dir, f"Limiti0101{ISTAT_YEAR}_g.zip")
    if not os.path.exists(zip_path):
        progress(0, f"Download confini ISTAT {ISTAT_YEAR}...")
        _download_to_file(ISTAT_URL, zip_path, progress, "Confini ISTAT")
    return zip_path


def comuni_layer(cache_dir, progress=_noop_progress):
    """Apre il layer dei comuni ISTAT direttamente dallo zip in cache."""
    zip_path = ensure_istat_zip(cache_dir, progress)
    with zipfile.ZipFile(zip_path) as archive:
        shp_names = [
            n for n in archive.namelist()
            if n.lower().endswith(".shp") and "/com" in n.lower()
        ]
    if not shp_names:
        raise DownloadError("Shapefile dei comuni non trovato nello zip ISTAT.")
    uri = f"/vsizip/{zip_path}/{shp_names[0]}"
    layer = QgsVectorLayer(uri, "comuni_istat", "ogr")
    if not layer.isValid():
        raise DownloadError("Impossibile aprire i comuni ISTAT dallo zip in cache.")
    return layer


def find_comune(layer, name):
    """Cerca il comune per nome (esatto, poi parziale).

    Ritorna ``(feature, None)`` se il match è univoco, altrimenti
    ``(None, [suggerimenti])``.
    """
    wanted = name.strip().lower()
    if not wanted:
        return None, []
    exact, partial = [], []
    for feature in layer.getFeatures():
        comune = (feature["COMUNE"] or "").strip()
        low = comune.lower()
        if low == wanted:
            exact.append(feature)
        elif wanted in low:
            partial.append(comune)
    if len(exact) == 1:
        return exact[0], None
    if exact:  # omonimi (es. Calliano): servono altri criteri, elenca
        return None, sorted({f["COMUNE"] for f in exact})
    return None, sorted(set(partial))[:12]


# ---------------------------------------------------------------- scrittura

def _write_layer(gpkg_path, layer_name, source_layer):
    options = QgsVectorFileWriter.SaveVectorOptions()
    options.driverName = "GPKG"
    options.layerName = layer_name
    options.actionOnExistingFile = (
        QgsVectorFileWriter.CreateOrOverwriteLayer
        if os.path.exists(gpkg_path)
        else QgsVectorFileWriter.CreateOrOverwriteFile
    )
    result = QgsVectorFileWriter.writeAsVectorFormatV3(
        source_layer, gpkg_path, QgsCoordinateTransformContext(), options
    )
    if result[0] != QgsVectorFileWriter.NoError:
        raise DownloadError(f"Errore scrivendo {layer_name}: {result[1]}")


def _memory_layer(geometry_type, crs_authid, name, fields=()):
    layer = QgsVectorLayer(f"{geometry_type}?crs={crs_authid}", name, "memory")
    if fields:
        layer.dataProvider().addAttributes(
            [QgsField(fname, ftype) for fname, ftype in fields]
        )
        layer.updateFields()
    return layer


def _transform(geometry, source_crs, target_crs):
    if source_crs.authid() == target_crs.authid():
        return geometry
    geom = QgsGeometry(geometry)
    geom.transform(QgsCoordinateTransform(source_crs, target_crs, QgsProject.instance()))
    return geom


# ---------------------------------------------------------------- limite comunale

def download_boundary(cache_dir, comune_name, target_crs, gpkg_path,
                      progress=_noop_progress):
    """Estrae il limite comunale ISTAT e lo salva nel GeoPackage.

    Ritorna ``(geometria nel CRS ISTAT, CRS ISTAT, nome ufficiale)``.
    """
    progress(2, "Apertura confini ISTAT...")
    layer = comuni_layer(cache_dir, progress)
    feature, suggestions = find_comune(layer, comune_name)
    if feature is None:
        hint = (
            "Comuni simili: " + ", ".join(suggestions)
            if suggestions
            else "Nessun comune simile trovato: controlla il nome."
        )
        raise DownloadError(f"Comune '{comune_name}' non trovato. {hint}")

    official_name = feature["COMUNE"]
    istat_crs = layer.crs()
    boundary = QgsGeometry(feature.geometry())

    progress(8, f"Salvataggio limite di {official_name}...")
    out = _memory_layer(
        "MultiPolygon",
        target_crs.authid(),
        LAYER_BOUNDARY,
        [
            ("comune", QMetaType.Type.QString),
            ("pro_com_t", QMetaType.Type.QString),
            ("cod_reg", QMetaType.Type.Int),
            ("cod_prov", QMetaType.Type.Int),
            ("fonte", QMetaType.Type.QString),
        ],
    )
    out_feature = QgsFeature(out.fields())
    out_feature.setAttributes(
        [
            official_name,
            str(feature["PRO_COM_T"]),
            int(feature["COD_REG"]),
            int(feature["COD_PROV"]) if "COD_PROV" in feature.fields().names() else None,
            ISTAT_LICENSE,
        ]
    )
    out_feature.setGeometry(_transform(boundary, istat_crs, target_crs))
    out.dataProvider().addFeature(out_feature)
    _write_layer(gpkg_path, LAYER_BOUNDARY, out)
    return boundary, istat_crs, official_name


def _write_boundary(gpkg_path, geometry, source_crs, target_crs, name, source_note):
    out = _memory_layer(
        "MultiPolygon",
        target_crs.authid(),
        LAYER_BOUNDARY,
        [("comune", QMetaType.Type.QString), ("fonte", QMetaType.Type.QString)],
    )
    feature = QgsFeature(out.fields())
    feature.setAttributes([name, source_note])
    feature.setGeometry(_transform(geometry, source_crs, target_crs))
    out.dataProvider().addFeature(feature)
    _write_layer(gpkg_path, LAYER_BOUNDARY, out)


def download_boundary_osm(place_name, target_crs, gpkg_path,
                          progress=_noop_progress):
    """Limite amministrativo da OpenStreetMap (Nominatim, mondiale).

    Usato in modalità inglese/estero, quando i confini ISTAT non coprono
    l'area di lavoro. Ritorna ``(geometria, CRS WGS84, nome trovato)``.
    """
    progress(2, f"Ricerca '{place_name}' su Nominatim (OSM)...")
    params = urllib.parse.urlencode(
        {"q": place_name, "format": "json", "polygon_geojson": 1, "limit": 1}
    )
    try:
        payload = _http_get(f"{NOMINATIM_URL}?{params}")
    except Exception as exc:
        raise DownloadError(f"Nominatim non raggiungibile: {exc}")
    results = json.loads(payload.decode("utf-8"))
    if not results:
        raise DownloadError(f"'{place_name}' non trovato su OpenStreetMap.")
    geojson = results[0].get("geojson") or {}
    if geojson.get("type") not in ("Polygon", "MultiPolygon"):
        raise DownloadError(
            f"'{place_name}' non ha un confine poligonale su OSM: "
            "prova con il nome del comune/città oppure usa un dataset tuo."
        )
    display_name = results[0].get("display_name", place_name)

    collection = json.dumps(
        {"type": "FeatureCollection",
         "features": [{"type": "Feature", "geometry": geojson, "properties": {}}]}
    )
    geojson_path = None
    try:
        with tempfile.NamedTemporaryFile(
            suffix=".geojson", delete=False, mode="w", encoding="utf-8"
        ) as handle:
            handle.write(collection)
            geojson_path = handle.name
        layer = QgsVectorLayer(geojson_path, "osm_boundary", "ogr")
        if not layer.isValid() or layer.featureCount() == 0:
            raise DownloadError("Confine OSM non leggibile.")
        boundary = QgsGeometry(next(layer.getFeatures()).geometry())
        crs = layer.crs()
        del layer
    finally:
        if geojson_path and os.path.exists(geojson_path):
            os.unlink(geojson_path)

    progress(8, f"Salvataggio limite OSM di {display_name}...")
    _write_boundary(
        gpkg_path, boundary, crs, target_crs, display_name,
        "OpenStreetMap contributors (Nominatim), ODbL",
    )
    return boundary, crs, display_name


def boundary_from_file(path, target_crs, gpkg_path, progress=_noop_progress):
    """Limite da un dataset poligonale fornito dall'utente.

    Tutte le geometrie del file vengono fuse (union) in un'unica area di
    ritaglio. Ritorna ``(geometria, CRS del file, nome del file)``.
    """
    progress(2, f"Lettura del dataset utente {os.path.basename(path)}...")
    layer = QgsVectorLayer(path, "user_boundary", "ogr")
    if not layer.isValid():
        raise DownloadError(f"Dataset non leggibile: {path}")
    geometries = [
        QgsGeometry(f.geometry()) for f in layer.getFeatures()
        if not f.geometry().isEmpty()
    ]
    if not geometries:
        raise DownloadError("Il dataset utente non contiene geometrie.")
    boundary = QgsGeometry.unaryUnion(geometries)
    if boundary.isEmpty():
        raise DownloadError("Unione delle geometrie del dataset fallita.")
    name = os.path.splitext(os.path.basename(path))[0]
    crs = layer.crs()

    progress(8, "Salvataggio limite dal dataset utente...")
    _write_boundary(
        gpkg_path, boundary, crs, target_crs, name, f"Dataset utente: {path}"
    )
    return boundary, crs, name


# ---------------------------------------------------------------- AdE WFS

def _tiles(rect, lat_mid):
    """Griglia di tile <= ADE_MAX_TILE_KM2 sopra un rettangolo lat/lon."""
    side_km = math.sqrt(ADE_MAX_TILE_KM2)
    dlat = side_km / 111.32
    dlon = side_km / (111.32 * max(0.1, math.cos(math.radians(lat_mid))))
    lat = rect.yMinimum()
    while lat < rect.yMaximum():
        lon = rect.xMinimum()
        while lon < rect.xMaximum():
            yield QgsRectangle(
                lon, lat, min(lon + dlon, rect.xMaximum()), min(lat + dlat, rect.yMaximum())
            )
            lon += dlon
        lat += dlat


def download_ade_parcels(boundary, boundary_crs, target_crs, gpkg_path,
                         progress=_noop_progress, is_canceled=_never_canceled,
                         area=None, area_crs=None):
    """Scarica le particelle AdE nell'area richiesta.

    ``area`` è la zona disegnata dall'utente (Shift+Trascina); la regione
    effettiva di download è sempre ``area ∩ limite comunale ISTAT``, così
    il ritaglio resta ancorato al confine ufficiale. Senza ``area`` viene
    scaricato l'intero comune.

    I poligoni sono salvati "muti": nessun attributo catastale, nessuna
    vestizione — solo la geometria. Ritorna il numero di particelle scritte.
    """
    ade_crs = QgsCoordinateReferenceSystem(ADE_CRS_AUTHID)
    boundary_ade = _transform(boundary, boundary_crs, ade_crs)
    if area is not None:
        area_ade = _transform(area, area_crs, ade_crs)
        boundary_ade = boundary_ade.intersection(area_ade)
        if boundary_ade.isEmpty():
            raise DownloadError(
                "L'area disegnata non tocca il limite comunale ISTAT: "
                "disegna un rettangolo dentro il confine."
            )

    bbox = boundary_ade.boundingBox()
    tiles = [
        t for t in _tiles(bbox, bbox.center().y())
        if boundary_ade.intersects(QgsGeometry.fromRect(t))
    ]
    if not tiles:
        raise DownloadError("Nessuna tile WFS interseca il limite comunale.")

    progress(0, f"Particelle AdE: {len(tiles)} tile da scaricare "
                f"(pausa {ADE_PAUSE_S}s tra le chiamate)...")

    geometries = {}
    for index, tile in enumerate(tiles, start=1):
        if is_canceled():
            raise DownloadError("Download annullato dall'utente.")
        bbox_str = (
            f"{tile.yMinimum():.7f},{tile.xMinimum():.7f},"
            f"{tile.yMaximum():.7f},{tile.xMaximum():.7f},"
            "urn:ogc:def:crs:EPSG::6706"
        )
        try:
            payload = _http_get(f"{ADE_WFS_URL}&bbox={bbox_str}")
        except Exception as exc:  # rete/timeout: meglio un errore chiaro
            raise DownloadError(f"WFS AdE non raggiungibile (tile {index}): {exc}")

        gml_path = None
        try:
            with tempfile.NamedTemporaryFile(
                suffix=".gml", delete=False, mode="wb"
            ) as handle:
                handle.write(payload)
                gml_path = handle.name
            tile_layer = QgsVectorLayer(gml_path, "tile", "ogr")
            if tile_layer.isValid():
                for feature in tile_layer.getFeatures():
                    geom = feature.geometry()
                    if geom.isEmpty():
                        continue
                    key = feature["gml_id"] if "gml_id" in feature.fields().names() \
                        else geom.boundingBox().toString(7)
                    if key in geometries:
                        continue
                    if not geom.boundingBoxIntersects(boundary_ade) or \
                            not geom.intersects(boundary_ade):
                        continue
                    # Ritaglio sul limite ISTAT: le particelle interne
                    # restano intere, quelle a cavallo vengono tagliate.
                    if boundary_ade.contains(geom):
                        geometries[key] = QgsGeometry(geom)
                    else:
                        clipped = geom.intersection(boundary_ade)
                        if not clipped.isEmpty():
                            geometries[key] = clipped
            del tile_layer
        finally:
            for path in (gml_path, (gml_path or "") + ".gfs"):
                if path and os.path.exists(path):
                    os.unlink(path)

        progress(
            index * 100 / len(tiles),
            f"Particelle AdE: tile {index}/{len(tiles)} — {len(geometries)} poligoni",
        )
        if index < len(tiles):
            time.sleep(ADE_PAUSE_S)

    out = _memory_layer("MultiPolygon", target_crs.authid(), LAYER_PARCELS)
    provider = out.dataProvider()
    for geom in geometries.values():
        feature = QgsFeature()
        feature.setGeometry(_transform(geom, ade_crs, target_crs))
        provider.addFeature(feature)
    _write_layer(gpkg_path, LAYER_PARCELS, out)
    return len(geometries)


# ---------------------------------------------------------------- OSM

def download_osm_roads(boundary, boundary_crs, target_crs, gpkg_path,
                       progress=_noop_progress, is_canceled=_never_canceled):
    """Scarica da Overpass tutte le strade OSM e le ritaglia sul limite.

    Ritorna il numero di tratti stradali scritti.
    """
    wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
    boundary_wgs = _transform(boundary, boundary_crs, wgs84)
    bbox = boundary_wgs.boundingBox()

    progress(5, "Interrogazione Overpass (strade OSM)...")
    query = (
        "[out:xml][timeout:180];"
        f'way["highway"]({bbox.yMinimum():.6f},{bbox.xMinimum():.6f},'
        f"{bbox.yMaximum():.6f},{bbox.xMaximum():.6f});"
        "(._;>;);out body;"
    )
    try:
        payload = _http_get(
            OVERPASS_URL, data=urllib.parse.urlencode({"data": query}).encode()
        )
    except Exception as exc:
        raise DownloadError(f"Overpass API non raggiungibile: {exc}")
    if is_canceled():
        raise DownloadError("Download annullato dall'utente.")

    osm_path = None
    count = 0
    try:
        with tempfile.NamedTemporaryFile(suffix=".osm", delete=False, mode="wb") as handle:
            handle.write(payload)
            osm_path = handle.name
        roads = QgsVectorLayer(osm_path + "|layername=lines", "osm", "ogr")
        if not roads.isValid():
            raise DownloadError("Risposta Overpass non leggibile (layer lines).")

        progress(60, "Ritaglio delle strade sul limite ISTAT...")
        out = _memory_layer(
            "MultiLineString",
            target_crs.authid(),
            LAYER_ROADS,
            [
                ("name", QMetaType.Type.QString),
                ("highway", QMetaType.Type.QString),
                ("fonte", QMetaType.Type.QString),
            ],
        )
        provider = out.dataProvider()
        for feature in roads.getFeatures():
            highway = feature["highway"]
            if not highway:
                continue
            geom = feature.geometry()
            if not geom.boundingBoxIntersects(boundary_wgs) or \
                    not geom.intersects(boundary_wgs):
                continue
            clipped = geom.intersection(boundary_wgs)
            if clipped.isEmpty():
                continue
            out_feature = QgsFeature(out.fields())
            out_feature.setAttributes(
                [feature["name"], highway, "OpenStreetMap contributors, ODbL"]
            )
            out_feature.setGeometry(_transform(clipped, wgs84, target_crs))
            provider.addFeature(out_feature)
            count += 1
        del roads
        _write_layer(gpkg_path, LAYER_ROADS, out)
    finally:
        if osm_path and os.path.exists(osm_path):
            os.unlink(osm_path)
    return count
