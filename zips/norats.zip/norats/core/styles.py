"""Simbologia ed etichette dei layer NoRats.

Le postazioni esca usano un "semaforo" basato sui giorni trascorsi
dall'ultima ispezione:

- verde:   ispezionata negli ultimi 15 giorni
- arancio: tra 15 e 30 giorni
- rosso:   oltre 30 giorni oppure mai ispezionata
"""
from qgis.core import (
    QgsCategorizedSymbolRenderer,
    QgsFillSymbol,
    QgsMarkerSymbol,
    QgsPalLayerSettings,
    QgsRendererCategory,
    QgsRuleBasedRenderer,
    QgsTextFormat,
    QgsVectorLayer,
    QgsVectorLayerSimpleLabeling,
)
from qgis.PyQt.QtGui import QColor, QFont

from . import schema

NAVY = "#1F3864"

_STATION_RULES = [
    (
        "Ispezionata (ultimi 15 gg)",
        '"last_inspection" IS NOT NULL AND "last_inspection" >= to_date(now()) - to_interval(\'15 days\')',
        "#2e7d32",
    ),
    (
        "Da ispezionare (15-30 gg)",
        '"last_inspection" IS NOT NULL '
        "AND \"last_inspection\" < to_date(now()) - to_interval('15 days') "
        "AND \"last_inspection\" >= to_date(now()) - to_interval('30 days')",
        "#ef6c00",
    ),
    (
        "In ritardo o mai ispezionata",
        '"last_inspection" IS NULL '
        "OR \"last_inspection\" < to_date(now()) - to_interval('30 days')",
        "#c62828",
    ),
]


def _marker(color: str, name: str = "circle", size: str = "3.6") -> QgsMarkerSymbol:
    return QgsMarkerSymbol.createSimple(
        {
            "name": name,
            "color": color,
            "outline_color": "#ffffff",
            "outline_width": "0.4",
            "size": size,
        }
    )


def apply_station_style(layer: QgsVectorLayer) -> None:
    root_rule = QgsRuleBasedRenderer.Rule(None)
    for label, expression, color in _STATION_RULES:
        rule = QgsRuleBasedRenderer.Rule(
            _marker(color, "square", "4.2"), filterExp=expression, label=label
        )
        root_rule.appendChild(rule)
    layer.setRenderer(QgsRuleBasedRenderer(root_rule))
    _label_by(layer, '"code"')
    layer.triggerRepaint()


def apply_sighting_style(layer: QgsVectorLayer) -> None:
    symbol = _marker("#b71c1c", "triangle", "3.4")
    layer.renderer().setSymbol(symbol)
    layer.triggerRepaint()


def apply_risk_area_style(layer: QgsVectorLayer) -> None:
    colors = {1: "#fff59d", 2: "#ffb74d", 3: "#e57373"}
    categories = []
    for level, label in schema.RISK_LEVELS.items():
        fill = QgsFillSymbol.createSimple(
            {
                "color": colors[level],
                "outline_color": NAVY,
                "outline_width": "0.5",
            }
        )
        fill.setOpacity(0.55)
        categories.append(QgsRendererCategory(level, fill, f"Rischio {label.lower()}"))
    layer.setRenderer(QgsCategorizedSymbolRenderer("risk_level", categories))
    _label_by(layer, '"name"')
    layer.triggerRepaint()


def _label_by(layer: QgsVectorLayer, expression: str) -> None:
    settings = QgsPalLayerSettings()
    settings.fieldName = expression
    settings.isExpression = True
    text_format = QgsTextFormat()
    font = QFont()
    font.setBold(True)
    text_format.setFont(font)
    text_format.setSize(9)
    text_format.setColor(QColor(NAVY))
    settings.setFormat(text_format)
    layer.setLabelsEnabled(True)
    layer.setLabeling(QgsVectorLayerSimpleLabeling(settings))


def apply_boundary_style(layer: QgsVectorLayer) -> None:
    """Limite comunale ISTAT: solo contorno, blu della famiglia SinoCloud."""
    symbol = QgsFillSymbol.createSimple(
        {
            "color": "0,0,0,0",
            "outline_color": "#5b9bd5",
            "outline_width": "0.9",
            "outline_style": "solid",
        }
    )
    layer.renderer().setSymbol(symbol)
    layer.triggerRepaint()


def apply_parcel_style(layer: QgsVectorLayer) -> None:
    """Particelle AdE "mute": nessun colore catastale, solo contorni grigi."""
    symbol = QgsFillSymbol.createSimple(
        {
            "color": "224,224,224,30",
            "outline_color": "#9e9e9e",
            "outline_width": "0.15",
        }
    )
    layer.renderer().setSymbol(symbol)
    layer.setLabelsEnabled(False)
    layer.triggerRepaint()


def apply_road_style(layer: QgsVectorLayer) -> None:
    """Strade OSM: linea neutra, nessuna gerarchia di colori."""
    from qgis.core import QgsLineSymbol

    symbol = QgsLineSymbol.createSimple({"color": "#6b7785", "width": "0.4"})
    layer.renderer().setSymbol(symbol)
    layer.triggerRepaint()


def apply_all(layers_by_name: dict) -> None:
    """Applica lo stile giusto a ogni layer NoRats presente nel dizionario."""
    if schema.STATIONS in layers_by_name:
        apply_station_style(layers_by_name[schema.STATIONS])
    if schema.SIGHTINGS in layers_by_name:
        apply_sighting_style(layers_by_name[schema.SIGHTINGS])
    if schema.RISK_AREAS in layers_by_name:
        apply_risk_area_style(layers_by_name[schema.RISK_AREAS])
