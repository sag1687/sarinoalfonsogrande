"""Moduli non-GUI di NoRats: schema dati, accesso al GeoPackage, stili, report."""
