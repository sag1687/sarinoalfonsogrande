"""Esportazione dei layer NoRats verso PostgreSQL/PostGIS.

Usa le connessioni PostgreSQL già salvate in QGIS (Browser → PostgreSQL →
Nuova connessione), quindi nessuna password viene gestita dal plugin: fa
fede la configurazione dell'utente (incluso l'eventuale autenticazione
QGIS). L'esportazione avviene con QgsVectorLayerExporter, lo stesso
meccanismo di "Esporta → Salva su PostGIS" di QGIS.
"""
from qgis.core import QgsDataSourceUri, QgsProviderRegistry, QgsVectorLayerExporter


class PostgisError(RuntimeError):
    """Errore di esportazione con messaggio pronto per l'utente."""


def _metadata():
    metadata = QgsProviderRegistry.instance().providerMetadata("postgres")
    if metadata is None:
        raise PostgisError(
            "Provider PostgreSQL non disponibile in questa installazione di QGIS."
        )
    return metadata


def connection_names() -> list:
    """Nomi delle connessioni PostgreSQL salvate in QGIS."""
    return sorted(_metadata().connections().keys())


def _connection(name: str):
    connections = _metadata().connections()
    if name not in connections:
        raise PostgisError(f"Connessione PostgreSQL '{name}' non trovata in QGIS.")
    return connections[name]


def export_layer(layer, connection_name: str, schema_name: str, table_name: str,
                 overwrite: bool = True) -> None:
    """Esporta un layer vettoriale nella tabella schema.tabella."""
    connection = _connection(connection_name)
    uri = QgsDataSourceUri(connection.uri())
    uri.setDataSource(schema_name, table_name, "geom" if layer.isSpatial() else None)

    error, message = QgsVectorLayerExporter.exportLayer(
        layer,
        uri.uri(False),
        "postgres",
        layer.crs(),
        onlySelected=False,
        options={"overwrite": overwrite},
    )
    if error != QgsVectorLayerExporter.NoError:
        raise PostgisError(
            f"Esportazione di '{table_name}' fallita: {message or error}"
        )


def export_layers(layers_by_table: dict, connection_name: str, schema_name: str,
                  progress=None) -> int:
    """Esporta più layer; ritorna quanti ne ha scritti."""
    total = len(layers_by_table)
    done = 0
    for table_name, layer in layers_by_table.items():
        if layer is None:
            continue
        if progress is not None:
            progress(done * 100 / max(1, total), f"PostGIS: esporto {table_name}...")
        export_layer(layer, connection_name, schema_name, table_name)
        done += 1
    if progress is not None:
        progress(100, f"PostGIS: {done} tabelle esportate in '{schema_name}'.")
    return done
