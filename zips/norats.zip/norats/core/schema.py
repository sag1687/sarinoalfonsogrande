"""Schema dati di NoRats: definizione di layer e campi del GeoPackage.

Ogni campagna di derattizzazione vive in un unico GeoPackage con quattro layer:

- ``bait_stations``  (punti)    postazioni esca sul territorio
- ``inspections``    (tabella)  storico delle ispezioni di ogni postazione
- ``sightings``      (punti)    avvistamenti di roditori segnalati
- ``risk_areas``     (poligoni) aree a rischio (aree private abbandonate,
                                isole ecologiche, tratti di rete fognaria)

Sulla postazione sono denormalizzati ``last_inspection`` e ``last_consumption``
(aggiornati a ogni ispezione registrata) così la simbologia a semaforo non deve
fare join con lo storico.
"""
from dataclasses import dataclass, field

from qgis.PyQt.QtCore import QMetaType
from qgis.core import QgsField, QgsFields

# CRS metrico (UTM 33N) adatto alla Calabria: coordinate in metri,
# indispensabile per un piano "al centimetro".
CRS_AUTHID = "EPSG:32633"

STATIONS = "bait_stations"
INSPECTIONS = "inspections"
SIGHTINGS = "sightings"
RISK_AREAS = "risk_areas"

STATION_CODE_PREFIX = "BS"

BAIT_TYPES = [
    "Esca anticoagulante",
    "Trappola meccanica",
    "Trappola a cattura viva",
    "Postazione di solo monitoraggio",
]

AREA_TYPES = [
    "Area privata abbandonata",
    "Isola ecologica",
    "Rete fognaria",
    "Altro",
]

RISK_LEVELS = {1: "Basso", 2: "Medio", 3: "Alto"}

STATION_STATUSES = ["Attiva", "Rimossa"]


@dataclass
class LayerSpec:
    """Descrive un layer del GeoPackage NoRats."""

    name: str
    geometry: str  # "Point", "Polygon" oppure "None" per tabelle senza geometria
    display_name: str
    fields: list = field(default_factory=list)  # liste (nome, tipo QMetaType.Type, lunghezza)

    def qgs_fields(self) -> QgsFields:
        fields = QgsFields()
        for fname, ftype, flen in self.fields:
            fields.append(QgsField(fname, ftype, len=flen))
        return fields

    def memory_uri(self) -> str:
        if self.geometry == "None":
            return "None"
        return f"{self.geometry}?crs={CRS_AUTHID}"


LAYERS = [
    LayerSpec(
        name=STATIONS,
        geometry="Point",
        display_name="Postazioni esca",
        fields=[
            ("code", QMetaType.Type.QString, 16),
            ("install_date", QMetaType.Type.QDate, 0),
            ("bait_type", QMetaType.Type.QString, 64),
            ("status", QMetaType.Type.QString, 16),
            ("location_desc", QMetaType.Type.QString, 254),
            ("last_inspection", QMetaType.Type.QDate, 0),
            ("last_consumption", QMetaType.Type.Int, 0),
            ("notes", QMetaType.Type.QString, 254),
        ],
    ),
    LayerSpec(
        name=INSPECTIONS,
        geometry="None",
        display_name="Ispezioni",
        fields=[
            ("station_code", QMetaType.Type.QString, 16),
            ("insp_date", QMetaType.Type.QDate, 0),
            ("consumption_pct", QMetaType.Type.Int, 0),
            ("bait_replaced", QMetaType.Type.Bool, 0),
            ("operator", QMetaType.Type.QString, 128),
            ("notes", QMetaType.Type.QString, 254),
        ],
    ),
    LayerSpec(
        name=SIGHTINGS,
        geometry="Point",
        display_name="Avvistamenti",
        fields=[
            ("sight_date", QMetaType.Type.QDate, 0),
            ("species", QMetaType.Type.QString, 64),
            ("individuals", QMetaType.Type.Int, 0),
            ("reporter", QMetaType.Type.QString, 128),
            ("notes", QMetaType.Type.QString, 254),
        ],
    ),
    LayerSpec(
        name=RISK_AREAS,
        geometry="Polygon",
        display_name="Aree a rischio",
        fields=[
            ("name", QMetaType.Type.QString, 128),
            ("area_type", QMetaType.Type.QString, 64),
            ("risk_level", QMetaType.Type.Int, 0),
            ("last_treatment", QMetaType.Type.QDate, 0),
            ("notes", QMetaType.Type.QString, 254),
        ],
    ),
]


def spec(name: str) -> LayerSpec:
    for layer_spec in LAYERS:
        if layer_spec.name == name:
            return layer_spec
    raise KeyError(f"Layer sconosciuto nello schema NoRats: {name}")
