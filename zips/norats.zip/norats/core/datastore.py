"""Accesso ai dati NoRats: creazione del GeoPackage e caricamento dei layer."""
from qgis.core import (
    QgsCoordinateTransformContext,
    QgsFeature,
    QgsProject,
    QgsVectorFileWriter,
    QgsVectorLayer,
)

from . import schema


def _empty_memory_layer(layer_spec: schema.LayerSpec) -> QgsVectorLayer:
    layer = QgsVectorLayer(layer_spec.memory_uri(), layer_spec.name, "memory")
    layer.dataProvider().addAttributes(layer_spec.qgs_fields())
    layer.updateFields()
    return layer


def create_geopackage(gpkg_path: str) -> None:
    """Crea (o sovrascrive) il GeoPackage con tutti i layer dello schema."""
    context = QgsCoordinateTransformContext()
    for index, layer_spec in enumerate(schema.LAYERS):
        source = _empty_memory_layer(layer_spec)
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "GPKG"
        options.layerName = layer_spec.name
        options.actionOnExistingFile = (
            QgsVectorFileWriter.CreateOrOverwriteFile
            if index == 0
            else QgsVectorFileWriter.CreateOrOverwriteLayer
        )
        result = QgsVectorFileWriter.writeAsVectorFormatV3(
            source, gpkg_path, context, options
        )
        if result[0] != QgsVectorFileWriter.NoError:
            raise RuntimeError(
                f"Errore scrivendo il layer {layer_spec.name} in {gpkg_path}: {result[1]}"
            )


def gpkg_layer(gpkg_path: str, layer_name: str) -> QgsVectorLayer:
    """Apre un singolo layer dal GeoPackage."""
    layer_spec = schema.spec(layer_name)
    layer = QgsVectorLayer(
        f"{gpkg_path}|layername={layer_name}", layer_spec.display_name, "ogr"
    )
    if not layer.isValid():
        raise RuntimeError(f"Layer {layer_name} non valido in {gpkg_path}")
    return layer


def project_layer(layer_name: str, project: QgsProject = None) -> QgsVectorLayer:
    """Trova un layer NoRats già caricato nel progetto corrente (per nome sorgente)."""
    project = project or QgsProject.instance()
    for layer in project.mapLayers().values():
        source = layer.source()
        if f"layername={layer_name}" in source:
            return layer
    return None


def next_station_code(stations_layer: QgsVectorLayer) -> str:
    """Genera il prossimo codice postazione progressivo (BS-001, BS-002, ...)."""
    highest = 0
    code_idx = stations_layer.fields().indexOf("code")
    for feature in stations_layer.getFeatures():
        value = feature[code_idx]
        if isinstance(value, str) and value.startswith(schema.STATION_CODE_PREFIX):
            try:
                highest = max(highest, int(value.split("-")[-1]))
            except ValueError:
                continue
    return f"{schema.STATION_CODE_PREFIX}-{highest + 1:03d}"


def add_feature(layer: QgsVectorLayer, attributes: dict, geometry=None) -> bool:
    """Inserisce una feature nel layer a partire da un dizionario campo -> valore."""
    feature = QgsFeature(layer.fields())
    for name, value in attributes.items():
        feature.setAttribute(name, value)
    if geometry is not None:
        feature.setGeometry(geometry)
    ok = layer.dataProvider().addFeature(feature)
    layer.updateExtents()
    layer.triggerRepaint()
    return ok


def update_station_after_inspection(
    stations_layer: QgsVectorLayer, station_code: str, insp_date, consumption_pct: int
) -> bool:
    """Aggiorna i campi denormalizzati della postazione dopo un'ispezione."""
    fields = stations_layer.fields()
    idx_code = fields.indexOf("code")
    idx_last = fields.indexOf("last_inspection")
    idx_cons = fields.indexOf("last_consumption")
    for feature in stations_layer.getFeatures():
        if feature[idx_code] == station_code:
            changes = {idx_last: insp_date, idx_cons: consumption_pct}
            ok = stations_layer.dataProvider().changeAttributeValues(
                {feature.id(): changes}
            )
            stations_layer.triggerRepaint()
            return ok
    return False


def station_codes(stations_layer: QgsVectorLayer, only_active: bool = True) -> list:
    """Elenco ordinato dei codici postazione (di default solo quelle attive)."""
    codes = []
    for feature in stations_layer.getFeatures():
        if only_active and feature["status"] != "Attiva":
            continue
        codes.append(feature["code"])
    return sorted(codes)
