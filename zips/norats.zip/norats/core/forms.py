"""Configurazione delle maschere di inserimento (form attributi) QGIS.

Ogni layer della campagna riceve widget di editing adeguati al dato:
tendine con i soli valori ammessi, calendari per le date, slider/range per
le percentuali, caselle di spunta per i booleani, alias leggibili in
italiano e campi calcolati in sola lettura. Così l'inserimento da QGIS
(modulo del layer o strumento "Aggiungi feature") è guidato e senza errori
di battitura.
"""
from qgis.core import QgsDefaultValue, QgsEditorWidgetSetup, QgsVectorLayer

from . import schema


def _value_map(values):
    """Widget a tendina con i soli valori ammessi."""
    return QgsEditorWidgetSetup("ValueMap", {"map": {v: v for v in values}})


def _date():
    return QgsEditorWidgetSetup(
        "DateTime",
        {
            "display_format": "dd/MM/yyyy",
            "field_format": "yyyy-MM-dd",
            "calendar_popup": True,
            "allow_null": True,
        },
    )


def _range_pct():
    return QgsEditorWidgetSetup(
        "Range",
        {"Min": 0, "Max": 100, "Step": 5, "Style": "Slider", "AllowNull": True},
    )


def _checkbox():
    return QgsEditorWidgetSetup(
        "CheckBox", {"CheckedState": "true", "UncheckedState": "false"}
    )


def _text(multiline=False):
    return QgsEditorWidgetSetup("TextEdit", {"IsMultiline": multiline})


def _apply(layer, config):
    """config: {campo: (alias, widget_setup, sola_lettura, default)}"""
    fields = layer.fields()
    form_config = layer.editFormConfig()
    for name, (alias, setup, read_only, default) in config.items():
        idx = fields.indexOf(name)
        if idx < 0:
            continue
        layer.setFieldAlias(idx, alias)
        if setup is not None:
            layer.setEditorWidgetSetup(idx, setup)
        form_config.setReadOnly(idx, read_only)
        if default:
            layer.setDefaultValueDefinition(idx, QgsDefaultValue(default))
    layer.setEditFormConfig(form_config)


def configure_stations_form(layer: QgsVectorLayer) -> None:
    _apply(
        layer,
        {
            "code": ("Codice postazione", _text(), True, None),
            "install_date": ("Data installazione", _date(), False, "to_date(now())"),
            "bait_type": ("Tipo di postazione", _value_map(schema.BAIT_TYPES), False, None),
            "status": ("Stato", _value_map(schema.STATION_STATUSES), False, "'Attiva'"),
            "location_desc": ("Ubicazione", _text(), False, None),
            "last_inspection": ("Ultima ispezione", _date(), True, None),
            "last_consumption": ("Ultimo consumo esca (%)", _range_pct(), True, None),
            "notes": ("Note", _text(multiline=True), False, None),
        },
    )


def configure_inspections_form(layer: QgsVectorLayer) -> None:
    _apply(
        layer,
        {
            "station_code": ("Codice postazione", _text(), False, None),
            "insp_date": ("Data ispezione", _date(), False, "to_date(now())"),
            "consumption_pct": ("Consumo esca (%)", _range_pct(), False, None),
            "bait_replaced": ("Esca sostituita", _checkbox(), False, None),
            "operator": ("Operatore", _text(), False, None),
            "notes": ("Note", _text(multiline=True), False, None),
        },
    )


def configure_sightings_form(layer: QgsVectorLayer) -> None:
    _apply(
        layer,
        {
            "sight_date": ("Data avvistamento", _date(), False, "to_date(now())"),
            "species": (
                "Specie",
                _value_map(["Rattus norvegicus", "Rattus rattus", "Mus musculus",
                            "Non identificata"]),
                False,
                "'Rattus norvegicus'",
            ),
            "individuals": (
                "Numero esemplari",
                QgsEditorWidgetSetup(
                    "Range", {"Min": 1, "Max": 500, "Step": 1, "Style": "SpinBox"}
                ),
                False,
                "1",
            ),
            "reporter": ("Segnalato da", _text(), False, None),
            "notes": ("Note", _text(multiline=True), False, None),
        },
    )


def configure_risk_areas_form(layer: QgsVectorLayer) -> None:
    _apply(
        layer,
        {
            "name": ("Nome area", _text(), False, None),
            "area_type": ("Tipologia", _value_map(schema.AREA_TYPES), False, None),
            "risk_level": (
                "Livello di rischio",
                QgsEditorWidgetSetup(
                    "ValueMap",
                    {"map": {f"{label} ({lv})": lv
                             for lv, label in schema.RISK_LEVELS.items()}},
                ),
                False,
                "2",
            ),
            "last_treatment": ("Ultimo trattamento", _date(), False, None),
            "notes": ("Note", _text(multiline=True), False, None),
        },
    )


_CONFIGURATORS = {
    schema.STATIONS: configure_stations_form,
    schema.INSPECTIONS: configure_inspections_form,
    schema.SIGHTINGS: configure_sightings_form,
    schema.RISK_AREAS: configure_risk_areas_form,
}


def configure_all(layers_by_name: dict) -> None:
    """Applica la maschera giusta a ogni layer NoRats presente."""
    for name, layer in layers_by_name.items():
        configurator = _CONFIGURATORS.get(name)
        if configurator is not None and layer is not None:
            configurator(layer)
