"""Classe principale del plugin NoRats: menu, toolbar e orchestrazione."""
import os

from qgis.core import QgsProject
from qgis.PyQt.QtCore import QUrl
from qgis.PyQt.QtGui import QDesktopServices, QIcon
from qgis.PyQt.QtWidgets import QAction, QDialog, QFileDialog, QMessageBox

from .core import datastore, forms, reports, schema, styles
from .gui.inspection_dialog import InspectionDialog
from .gui.main_dialog import NoRatsDialog
from .gui.map_tools import AddStationTool
from .gui.station_dialog import StationDialog

MENU_TITLE = "&NoRats"


class NoRatsPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.actions = []
        self.toolbar = None
        self.add_station_tool = None
        self.main_dialog = None

    # ------------------------------------------------------------------ setup

    def initGui(self):
        icon = QIcon(os.path.join(os.path.dirname(__file__), "icons", "norats.svg"))
        self.toolbar = self.iface.addToolBar("NoRats")
        self.toolbar.setObjectName("NoRatsToolbar")
        self._add_action(
            icon, "NoRats — Gestione derattizzazione...", lambda: self.open_main_dialog()
        )

    def _add_action(self, icon, text, slot):
        action = QAction(icon, text, self.iface.mainWindow())
        action.triggered.connect(slot)
        self.toolbar.addAction(action)
        self.iface.addPluginToMenu(MENU_TITLE, action)
        self.actions.append(action)

    def unload(self):
        for action in self.actions:
            self.iface.removePluginMenu(MENU_TITLE, action)
        self.actions = []
        if self.toolbar is not None:
            del self.toolbar
            self.toolbar = None
        if self.main_dialog is not None:
            self.main_dialog.close()
            self.main_dialog = None

    # ------------------------------------------------------------- azioni

    def new_campaign(self):
        path, _ = QFileDialog.getSaveFileName(
            self.iface.mainWindow(),
            "Nuova campagna NoRats — scegli dove salvare il GeoPackage",
            "",
            "GeoPackage (*.gpkg)",
        )
        if not path:
            return
        if not path.lower().endswith(".gpkg"):
            path += ".gpkg"
        try:
            datastore.create_geopackage(path)
        except RuntimeError as exc:
            QMessageBox.critical(self.iface.mainWindow(), "NoRats", str(exc))
            return
        self._load_campaign_layers(path)
        self.iface.messageBar().pushSuccess(
            "NoRats", f"Campagna creata: {os.path.basename(path)}"
        )

    def _load_campaign_layers(self, gpkg_path):
        project = QgsProject.instance()
        loaded = {}
        # Le tabelle sotto, i punti sopra: si caricano in ordine inverso.
        for layer_spec in reversed(schema.LAYERS):
            layer = datastore.gpkg_layer(gpkg_path, layer_spec.name)
            project.addMapLayer(layer)
            loaded[layer_spec.name] = layer
        styles.apply_all(loaded)
        forms.configure_all(loaded)

    def start_add_station(self):
        stations = self._require_layer(schema.STATIONS)
        if stations is None:
            return
        self.add_station_tool = AddStationTool(
            self.iface.mapCanvas(), stations, self._station_clicked
        )
        self.iface.mapCanvas().setMapTool(self.add_station_tool)
        self.iface.messageBar().pushInfo(
            "NoRats", "Clicca sulla mappa nel punto in cui installare la postazione."
        )

    def _station_clicked(self, geometry):
        stations = self._require_layer(schema.STATIONS)
        if stations is None:
            return
        dialog = StationDialog(
            datastore.next_station_code(stations), self.iface.mainWindow()
        )
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        datastore.add_feature(stations, dialog.values(), geometry)
        self.iface.mapCanvas().unsetMapTool(self.add_station_tool)
        self.iface.messageBar().pushSuccess(
            "NoRats", f"Postazione {dialog.values()['code']} aggiunta."
        )

    def record_inspection(self):
        stations = self._require_layer(schema.STATIONS)
        inspections = self._require_layer(schema.INSPECTIONS)
        if stations is None or inspections is None:
            return
        codes = datastore.station_codes(stations)
        if not codes:
            QMessageBox.information(
                self.iface.mainWindow(),
                "NoRats",
                "Nessuna postazione attiva: aggiungi prima una postazione esca.",
            )
            return
        dialog = InspectionDialog(codes, self.iface.mainWindow())
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        values = dialog.values()
        datastore.add_feature(inspections, values)
        datastore.update_station_after_inspection(
            stations, values["station_code"], values["insp_date"], values["consumption_pct"]
        )
        self.iface.messageBar().pushSuccess(
            "NoRats", f"Ispezione registrata per {values['station_code']}."
        )

    def generate_report(self):
        layers = {}
        for name in (schema.STATIONS, schema.INSPECTIONS, schema.SIGHTINGS, schema.RISK_AREAS):
            layers[name] = self._require_layer(name)
            if layers[name] is None:
                return
        path, _ = QFileDialog.getSaveFileName(
            self.iface.mainWindow(),
            "Salva report derattizzazione",
            "report_derattizzazione.html",
            "Pagina HTML (*.html)",
        )
        if not path:
            return
        reports.save_report(
            path,
            stations_layer=layers[schema.STATIONS],
            inspections_layer=layers[schema.INSPECTIONS],
            sightings_layer=layers[schema.SIGHTINGS],
            risk_layer=layers[schema.RISK_AREAS],
        )
        QDesktopServices.openUrl(QUrl.fromLocalFile(path))
        self.iface.messageBar().pushSuccess("NoRats", f"Report salvato: {path}")

    def open_main_dialog(self, tab_index=0):
        if self.main_dialog is None:
            self.main_dialog = NoRatsDialog(self, parent=self.iface.mainWindow())
        self.main_dialog.tabs.setCurrentIndex(tab_index)
        self.main_dialog.show()
        self.main_dialog.raise_()

    # ------------------------------------------------------------- utilità

    def _require_layer(self, name):
        layer = datastore.project_layer(name)
        if layer is None:
            QMessageBox.warning(
                self.iface.mainWindow(),
                "NoRats",
                f"Layer '{schema.spec(name).display_name}' non trovato nel progetto.\n"
                "Apri il progetto della campagna oppure creane una nuova con "
                "'Nuova campagna di derattizzazione'.",
            )
        return layer
