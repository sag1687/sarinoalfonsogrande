"""Finestra di inserimento di una nuova postazione esca."""
from qgis.PyQt.QtCore import QDate
from qgis.PyQt.QtWidgets import (
    QComboBox,
    QDateEdit,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QLineEdit,
    QPlainTextEdit,
)

from .. import plugin_hub
from ..core import schema


class StationDialog(QDialog):
    def __init__(self, next_code: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle("NoRats — Nuova postazione esca")
        self.setMinimumWidth(420)
        self.setStyleSheet(plugin_hub.FAMILY_STYLE)

        self.code_edit = QLineEdit(next_code)
        self.code_edit.setReadOnly(True)

        self.bait_combo = QComboBox()
        self.bait_combo.addItems(schema.BAIT_TYPES)

        self.date_edit = QDateEdit(QDate.currentDate())
        self.date_edit.setCalendarPopup(True)
        self.date_edit.setDisplayFormat("dd/MM/yyyy")

        self.location_edit = QLineEdit()
        self.location_edit.setPlaceholderText("es. Via Roma, angolo isola ecologica")

        self.notes_edit = QPlainTextEdit()
        self.notes_edit.setFixedHeight(70)

        layout = QFormLayout(self)
        layout.addRow("Codice postazione:", self.code_edit)
        layout.addRow("Tipo di postazione:", self.bait_combo)
        layout.addRow("Data installazione:", self.date_edit)
        layout.addRow("Ubicazione:", self.location_edit)
        layout.addRow("Note:", self.notes_edit)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel,
            parent=self,
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)

    def values(self) -> dict:
        return {
            "code": self.code_edit.text(),
            "install_date": self.date_edit.date(),
            "bait_type": self.bait_combo.currentText(),
            "status": "Attiva",
            "location_desc": self.location_edit.text(),
            "last_inspection": None,
            "last_consumption": None,
            "notes": self.notes_edit.toPlainText(),
        }
