"""Finestra principale di NoRats: un'unica icona, tutte le schede.

- **Campagna**: nuova campagna, postazioni, ispezioni, report,
  esportazione PostgreSQL/PostGIS.
- **Dati territoriali**: limite comunale (🇮🇹 ISTAT, 🌍 OSM/Nominatim o
  📁 dataset utente), strade OSM e particelle AdE con Shift+Trascina.
- **Informazioni e Licenza**: scheda info della famiglia SinoCloud.

Il pulsante bandiera cambia lingua e, con essa, la fonte suggerita del
limite: italiano → ISTAT, inglese → OSM o dataset dell'utente.
"""
import os

from qgis.core import (
    QgsApplication,
    QgsCoordinateReferenceSystem,
    QgsGeometry,
    QgsProject,
    QgsSettings,
    QgsTask,
    QgsVectorLayer,
)
from qgis.gui import QgsProjectionSelectionWidget
from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.PyQt.QtGui import QPixmap
from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QFrame,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QTabWidget,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)

from .. import plugin_hub
from ..core import downloads, postgis, schema, styles
from .map_tools import ShiftDragAreaTool

_SETTINGS_BASE = "norats"

SOURCE_ISTAT = "istat"
SOURCE_OSM = "osm"
SOURCE_FILE = "file"


def _t(lang, it, en):
    return en if lang == "en" else it


# ======================================================================
# Task in background
# ======================================================================

class DownloadTask(QgsTask):
    """Fase 1 in background: limite (ISTAT / OSM / file) e strade OSM."""

    message = pyqtSignal(str)

    def __init__(self, source, place_or_path, target_crs, gpkg_path,
                 want_roads, cache_dir):
        super().__init__("NoRats — download limite e strade", QgsTask.CanCancel)
        self.source = source
        self.place_or_path = place_or_path
        self.target_crs = target_crs
        self.gpkg_path = gpkg_path
        self.want_roads = want_roads
        self.cache_dir = cache_dir
        self.error = None
        self.official_name = None
        self.boundary = None      # geometria nel CRS di origine, per la fase AdE
        self.boundary_crs = None
        self.n_roads = 0
        self.on_done = None  # impostata dal dialogo

    def run(self):
        try:
            def progress(percent, message, base=0, span=100):
                self.setProgress(base + percent * span / 100)
                self.message.emit(message)

            step1 = lambda p, m: progress(p, m, 0, 35)  # noqa: E731
            if self.source == SOURCE_OSM:
                result = downloads.download_boundary_osm(
                    self.place_or_path, self.target_crs, self.gpkg_path, step1
                )
            elif self.source == SOURCE_FILE:
                result = downloads.boundary_from_file(
                    self.place_or_path, self.target_crs, self.gpkg_path, step1
                )
            else:
                result = downloads.download_boundary(
                    self.cache_dir, self.place_or_path, self.target_crs,
                    self.gpkg_path, step1,
                )
            self.boundary, self.boundary_crs, self.official_name = result

            if self.want_roads:
                if self.isCanceled():
                    return False
                self.n_roads = downloads.download_osm_roads(
                    self.boundary,
                    self.boundary_crs,
                    self.target_crs,
                    self.gpkg_path,
                    lambda p, m: progress(p, m, 40, 60),
                    self.isCanceled,
                )
            self.setProgress(100)
            return True
        except downloads.DownloadError as exc:
            self.error = str(exc)
            return False
        except Exception as exc:  # imprevisti: mostrali comunque all'utente
            self.error = f"Errore inatteso: {exc}"
            return False

    def finished(self, ok):
        if self.on_done is not None:
            self.on_done(ok, self)


class AdeTask(QgsTask):
    """Fase 2 in background: particelle AdE nell'area disegnata."""

    message = pyqtSignal(str)

    def __init__(self, boundary, boundary_crs, target_crs, gpkg_path, area,
                 area_crs):
        super().__init__("NoRats — download particelle AdE", QgsTask.CanCancel)
        self.boundary = boundary
        self.boundary_crs = boundary_crs
        self.target_crs = target_crs
        self.gpkg_path = gpkg_path
        self.area = area
        self.area_crs = area_crs
        self.error = None
        self.n_parcels = 0
        self.on_done = None

    def run(self):
        try:
            def progress(percent, message):
                self.setProgress(percent)
                self.message.emit(message)

            self.n_parcels = downloads.download_ade_parcels(
                self.boundary,
                self.boundary_crs,
                self.target_crs,
                self.gpkg_path,
                progress,
                self.isCanceled,
                area=self.area,
                area_crs=self.area_crs,
            )
            return True
        except downloads.DownloadError as exc:
            self.error = str(exc)
            return False
        except Exception as exc:
            self.error = f"Errore inatteso: {exc}"
            return False

    def finished(self, ok):
        if self.on_done is not None:
            self.on_done(ok, self)


# ======================================================================
# Finestra principale
# ======================================================================

class NoRatsDialog(QDialog):
    """Unica finestra del plugin: Campagna, Dati territoriali, Info."""

    def __init__(self, plugin, parent=None):
        super().__init__(parent)
        self.plugin = plugin          # NoRatsPlugin, per le azioni campagna
        self.iface = plugin.iface if plugin is not None else None
        self.lang = self._load_lang()
        self.task = None
        self.ade_task = None
        self.area_tool = None
        self._campaign = None  # stato fase 1: (boundary, crs, target_crs, gpkg)
        self._icons_dir = os.path.join(
            os.path.dirname(os.path.dirname(__file__)), "icons"
        )
        self._build_ui()
        self._apply_styles()
        self._update_ui_lang()

    # ------------------------------------------------------------- lingua

    def _load_lang(self):
        saved = QgsSettings().value(_SETTINGS_BASE + "/lang", "") or ""
        return saved if saved in ("it", "en") else "it"

    def _toggle_lang(self):
        self.lang = "en" if self.lang == "it" else "it"
        QgsSettings().setValue(_SETTINGS_BASE + "/lang", self.lang)
        # La lingua suggerisce la fonte del limite: IT -> ISTAT, EN -> OSM.
        self.combo_source.setCurrentIndex(0 if self.lang == "it" else 1)
        self._update_ui_lang()

    # ------------------------------------------------------------------ UI

    def _build_ui(self):
        self.setMinimumWidth(600)
        main = QVBoxLayout(self)

        header = QHBoxLayout()
        logo = QLabel()
        icon_path = os.path.join(self._icons_dir, "norats.svg")
        logo.setPixmap(QPixmap(icon_path).scaledToHeight(
            46, Qt.TransformationMode.SmoothTransformation))
        header.addWidget(logo)
        self.label_title = QLabel()
        header.addWidget(self.label_title, 1)
        self.btn_lang = QPushButton()
        self.btn_lang.setObjectName("btnLang")
        self.btn_lang.clicked.connect(self._toggle_lang)
        header.addWidget(self.btn_lang)
        main.addLayout(header)

        self.tabs = QTabWidget()
        main.addWidget(self.tabs)
        self.tabs.addTab(self._build_campaign_tab(), "")
        self.tabs.addTab(self._build_download_tab(), "")
        self.tabs.addTab(self._build_info_tab(), "")

    # ------------------------------------------------ scheda Campagna

    def _build_campaign_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        self.group_campaign = QGroupBox()
        campaign_layout = QVBoxLayout(self.group_campaign)
        self.btn_new_campaign = QPushButton()
        self.btn_new_campaign.clicked.connect(self._campaign_action("new_campaign"))
        self.btn_add_station = QPushButton()
        self.btn_add_station.clicked.connect(
            self._campaign_action("start_add_station", minimize=True)
        )
        self.btn_inspection = QPushButton()
        self.btn_inspection.clicked.connect(
            self._campaign_action("record_inspection")
        )
        self.btn_report = QPushButton()
        self.btn_report.clicked.connect(self._campaign_action("generate_report"))
        for btn in (self.btn_new_campaign, self.btn_add_station,
                    self.btn_inspection, self.btn_report):
            campaign_layout.addWidget(btn)
        layout.addWidget(self.group_campaign)

        self.group_pg = QGroupBox()
        pg_layout = QVBoxLayout(self.group_pg)
        self.label_pg = QLabel()
        self.label_pg.setWordWrap(True)
        pg_layout.addWidget(self.label_pg)
        row = QHBoxLayout()
        self.combo_pg = QComboBox()
        row.addWidget(self.combo_pg, 1)
        self.btn_pg_refresh = QPushButton("⟳")
        self.btn_pg_refresh.setMaximumWidth(36)
        self.btn_pg_refresh.clicked.connect(self._refresh_pg_connections)
        row.addWidget(self.btn_pg_refresh)
        pg_layout.addLayout(row)
        schema_row = QHBoxLayout()
        self.label_pg_schema = QLabel()
        schema_row.addWidget(self.label_pg_schema)
        self.edit_pg_schema = QLineEdit("norats")
        schema_row.addWidget(self.edit_pg_schema, 1)
        pg_layout.addLayout(schema_row)
        self.btn_pg_export = QPushButton()
        self.btn_pg_export.clicked.connect(self._export_postgis)
        pg_layout.addWidget(self.btn_pg_export)
        layout.addWidget(self.group_pg)
        layout.addStretch(1)

        self._refresh_pg_connections()
        return tab

    def _campaign_action(self, method_name, minimize=False):
        def runner():
            if self.plugin is None:
                return
            if minimize:
                self.showMinimized()
            getattr(self.plugin, method_name)()
        return runner

    def _refresh_pg_connections(self):
        self.combo_pg.clear()
        try:
            self.combo_pg.addItems(postgis.connection_names())
        except postgis.PostgisError:
            pass

    def _export_postgis(self):
        connection = self.combo_pg.currentText()
        schema_name = self.edit_pg_schema.text().strip() or "norats"
        if not connection:
            QMessageBox.warning(
                self, "NoRats",
                _t(self.lang,
                   "Nessuna connessione PostgreSQL salvata in QGIS.\n"
                   "Creane una dal Browser: PostgreSQL → Nuova connessione.",
                   "No PostgreSQL connection saved in QGIS.\n"
                   "Create one from the Browser: PostgreSQL → New connection."),
            )
            return
        # Tutti i layer NoRats presenti nel progetto, campagna e territoriali
        names = [s.name for s in schema.LAYERS] + [
            downloads.LAYER_BOUNDARY, downloads.LAYER_PARCELS, downloads.LAYER_ROADS
        ]
        project = QgsProject.instance()
        to_export = {}
        for layer in project.mapLayers().values():
            for name in names:
                if layer.source().endswith(f"layername={name}"):
                    to_export[name] = layer
        if not to_export:
            QMessageBox.information(
                self, "NoRats",
                _t(self.lang,
                   "Nessun layer NoRats nel progetto: apri o crea prima "
                   "una campagna.",
                   "No NoRats layer in the project: open or create a "
                   "campaign first."),
            )
            return
        try:
            count = postgis.export_layers(
                to_export, connection, schema_name,
                progress=lambda p, m: self._log(m),
            )
        except postgis.PostgisError as exc:
            QMessageBox.critical(self, "NoRats", str(exc))
            return
        QMessageBox.information(
            self, "NoRats",
            _t(self.lang,
               f"{count} tabelle esportate su '{connection}' "
               f"nello schema '{schema_name}'.",
               f"{count} tables exported to '{connection}' "
               f"in schema '{schema_name}'."),
        )

    # ---------------------------------------------- scheda Dati territoriali

    def _build_download_tab(self):
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        tab = QWidget()
        scroll.setWidget(tab)
        layout = QVBoxLayout(tab)

        self.group_comune = QGroupBox()
        comune_layout = QVBoxLayout(self.group_comune)
        self.combo_source = QComboBox()
        self.combo_source.addItem("", SOURCE_ISTAT)
        self.combo_source.addItem("", SOURCE_OSM)
        self.combo_source.addItem("", SOURCE_FILE)
        self.combo_source.currentIndexChanged.connect(self._source_changed)
        comune_layout.addWidget(self.combo_source)
        self.edit_comune = QLineEdit()
        comune_layout.addWidget(self.edit_comune)
        self.edit_boundary_file = QLineEdit()
        self.btn_boundary_file = QPushButton("...")
        self.btn_boundary_file.setMaximumWidth(40)
        self.btn_boundary_file.clicked.connect(self._browse_boundary_file)
        file_container = QWidget()
        file_container.setLayout(QHBoxLayout())
        file_container.layout().setContentsMargins(0, 0, 0, 0)
        file_container.layout().addWidget(self.edit_boundary_file, 1)
        file_container.layout().addWidget(self.btn_boundary_file)
        self.file_container = file_container
        comune_layout.addWidget(file_container)
        self.label_istat = QLabel()
        self.label_istat.setWordWrap(True)
        comune_layout.addWidget(self.label_istat)
        layout.addWidget(self.group_comune)

        self.group_data = QGroupBox()
        data_layout = QVBoxLayout(self.group_data)
        self.chk_boundary = QCheckBox()
        self.chk_boundary.setChecked(True)
        self.chk_boundary.setEnabled(False)  # è l'area di ritaglio: sempre
        self.chk_roads = QCheckBox()
        self.chk_roads.setChecked(True)
        for chk in (self.chk_boundary, self.chk_roads):
            data_layout.addWidget(chk)
        layout.addWidget(self.group_data)

        self.group_output = QGroupBox()
        out_layout = QVBoxLayout(self.group_output)
        self.crs_widget = QgsProjectionSelectionWidget()
        self.crs_widget.setCrs(QgsProject.instance().crs()
                               if QgsProject.instance().crs().isValid()
                               else QgsCoordinateReferenceSystem("EPSG:32633"))
        out_layout.addWidget(self.crs_widget)
        row = QHBoxLayout()
        self.edit_output = QLineEdit()
        row.addWidget(self.edit_output, 1)
        self.btn_browse = QPushButton("...")
        self.btn_browse.setMaximumWidth(40)
        self.btn_browse.clicked.connect(self._browse_output)
        row.addWidget(self.btn_browse)
        out_layout.addLayout(row)
        layout.addWidget(self.group_output)

        self.btn_scarica = QPushButton()
        self.btn_scarica.setObjectName("btn_scarica")
        self.btn_scarica.clicked.connect(self._start_download)
        layout.addWidget(self.btn_scarica)

        self.group_ade = QGroupBox()
        ade_layout = QVBoxLayout(self.group_ade)
        self.label_ade = QLabel()
        self.label_ade.setWordWrap(True)
        ade_layout.addWidget(self.label_ade)
        self.btn_ade = QPushButton()
        self.btn_ade.setEnabled(False)  # si abilita dopo la fase 1
        self.btn_ade.clicked.connect(self._start_ade_area)
        ade_layout.addWidget(self.btn_ade)
        layout.addWidget(self.group_ade)

        self.btn_annulla = QPushButton()
        self.btn_annulla.clicked.connect(self._cancel_download)
        self.btn_annulla.setVisible(False)
        layout.addWidget(self.btn_annulla)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        layout.addWidget(self.progress)

        self.txt_console = QPlainTextEdit()
        self.txt_console.setObjectName("txt_console")
        self.txt_console.setReadOnly(True)
        self.txt_console.setFixedHeight(110)
        layout.addWidget(self.txt_console)
        layout.addStretch(1)

        self._source_changed(0)
        return scroll

    def _source_changed(self, _index):
        source = self.combo_source.currentData()
        self.file_container.setVisible(source == SOURCE_FILE)
        self.edit_comune.setVisible(source != SOURCE_FILE)

    def _browse_boundary_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            _t(self.lang, "Dataset poligonale del limite",
               "Polygon boundary dataset"),
            os.path.expanduser("~"),
            "Vettori (*.gpkg *.shp *.geojson *.json *.kml);;Tutti i file (*)",
        )
        if path:
            self.edit_boundary_file.setText(path)

    # ------------------------------------------------------ scheda Info

    def _build_info_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        logo_row = QHBoxLayout()
        logo = QLabel()
        logo_path = os.path.join(self._icons_dir, "sinocloud-logo.png")
        if os.path.exists(logo_path):
            logo.setPixmap(QPixmap(logo_path).scaledToHeight(
                40, Qt.TransformationMode.SmoothTransformation))
        logo_row.addWidget(logo)
        logo_row.addStretch(1)
        layout.addLayout(logo_row)

        self.info_browser = QTextBrowser()
        self.info_browser.setOpenExternalLinks(True)
        layout.addWidget(self.info_browser, 1)

        self.family_widget = plugin_hub.make_family_widget("norats", self.lang)
        layout.addWidget(self.family_widget)
        return tab

    def _apply_styles(self):
        self.setStyleSheet(plugin_hub.FAMILY_STYLE + """
        QPushButton#btn_scarica { font-size: 14px; padding: 10px; }
        QPlainTextEdit#txt_console {
            background-color: #10151c;
            color: #5b9bd5;
            font-family: Consolas, monospace;
        }
        """)

    # ------------------------------------------------------------- testi

    def _update_ui_lang(self):
        L = self.lang
        self.btn_lang.setText(plugin_hub.lang_button_label(L))
        self.setWindowTitle(
            _t(L, "NoRats — Gestione derattizzazione",
               "NoRats — Rat-control management")
        )
        self.label_title.setText(
            '<span style="font-size:16pt; font-weight:700; color:#f2f5f8;">'
            "NoRats</span><br/>"
            '<span style="font-size:9pt; color:#8a97a5;">'
            + _t(
                L,
                "Derattizzazione su base GIS · ISTAT · AdE · OSM · PostGIS",
                "GIS-based rat control · ISTAT · AdE · OSM · PostGIS",
            )
            + "</span>"
        )
        self.tabs.setTabText(0, _t(L, "Campagna", "Campaign"))
        self.tabs.setTabText(1, _t(L, "Dati territoriali", "Territorial data"))
        self.tabs.setTabText(
            2, _t(L, "Informazioni e Licenza", "Information and License")
        )

        # --- Campagna
        self.group_campaign.setTitle(
            _t(L, "Campagna di derattizzazione", "Rat-control campaign")
        )
        self.btn_new_campaign.setText(
            _t(L, "🆕 Nuova campagna (GeoPackage con maschere)",
               "🆕 New campaign (GeoPackage with forms)")
        )
        self.btn_add_station.setText(
            _t(L, "📍 Aggiungi postazione esca (clic su mappa)",
               "📍 Add bait station (map click)")
        )
        self.btn_inspection.setText(
            _t(L, "📝 Registra ispezione...", "📝 Record inspection...")
        )
        self.btn_report.setText(
            _t(L, "📊 Genera report HTML...", "📊 Generate HTML report...")
        )
        self.group_pg.setTitle("PostgreSQL / PostGIS")
        self.label_pg.setText(
            _t(
                L,
                "Esporta tutti i layer NoRats del progetto in un database "
                "PostGIS, usando una connessione PostgreSQL salvata in QGIS.",
                "Exports every NoRats layer of the project to a PostGIS "
                "database, using a PostgreSQL connection saved in QGIS.",
            )
        )
        self.label_pg_schema.setText(_t(L, "Schema:", "Schema:"))
        self.btn_pg_export.setText(
            _t(L, "Esporta campagna su PostgreSQL",
               "Export campaign to PostgreSQL")
        )

        # --- Dati territoriali
        self.group_comune.setTitle(
            _t(L, "Limite dell'area di lavoro (area di ritaglio)",
               "Working-area boundary (clipping area)")
        )
        self.combo_source.setItemText(
            0, _t(L, "🇮🇹 ISTAT — comuni italiani (ufficiale)",
                  "🇮🇹 ISTAT — Italian municipalities (official)")
        )
        self.combo_source.setItemText(
            1, _t(L, "🌍 OpenStreetMap (Nominatim) — tutto il mondo",
                  "🌍 OpenStreetMap (Nominatim) — worldwide")
        )
        self.combo_source.setItemText(
            2, _t(L, "📁 Dataset dell'utente (file poligonale)",
                  "📁 User dataset (polygon file)")
        )
        self.edit_comune.setPlaceholderText(
            _t(L, "es. Mandatoriccio", "e.g. Grimsby, UK")
        )
        self.edit_boundary_file.setPlaceholderText(
            _t(L, "File poligonale (.gpkg, .shp, .geojson...)",
               "Polygon file (.gpkg, .shp, .geojson...)")
        )
        self.label_istat.setText(
            _t(
                L,
                f"🇮🇹 ISTAT: confini amministrativi {downloads.ISTAT_YEAR} "
                "generalizzati, scaricati una volta e tenuti in cache. "
                "🌍 In inglese/estero usa OSM oppure un tuo dataset. "
                "Il limite è l'area di ritaglio di tutti i dati.",
                f"🇮🇹 ISTAT: generalized administrative boundaries "
                f"{downloads.ISTAT_YEAR}, downloaded once and cached. "
                "🌍 Abroad use OSM or your own dataset. The boundary is "
                "the clipping area of every dataset.",
            )
        )
        self.group_data.setTitle(_t(L, "Dati da scaricare", "Data to download"))
        self.chk_boundary.setText(
            _t(L, "Limite dell'area (sempre incluso)",
               "Area boundary (always included)")
        )
        self.chk_roads.setText(
            _t(L, "Strade OpenStreetMap (tutte, ritagliate sul limite)",
               "OpenStreetMap roads (all of them, clipped on the boundary)")
        )
        self.group_output.setTitle(
            _t(L, "Output: sistema di riferimento e GeoPackage",
               "Output: reference system and GeoPackage")
        )
        self.edit_output.setPlaceholderText(
            _t(L, "Percorso del GeoPackage di destinazione (.gpkg)",
               "Destination GeoPackage path (.gpkg)")
        )
        self.btn_scarica.setText(
            _t(L, "1) SCARICA LIMITI COMUNALI E STRADE",
               "1) DOWNLOAD BOUNDARY AND ROADS")
        )
        self.group_ade.setTitle(
            _t(L, "Particelle catastali AdE (poligoni muti — solo Italia)",
               "AdE cadastral parcels (mute polygons — Italy only)")
        )
        self.label_ade.setText(
            _t(
                L,
                "Dopo la fase 1, disegna sulla mappa l'area da scaricare con "
                "<b>Shift+Trascina</b>: le particelle vengono comunque "
                "ritagliate sul limite. Poligoni muti: nessun attributo, "
                "colore o simbolo dell'Agenzia.",
                "After step 1, draw the area to download on the map with "
                "<b>Shift+Drag</b>: parcels are clipped on the boundary "
                "anyway. Mute polygons: no attributes, Agency colors or "
                "symbols.",
            )
        )
        self.btn_ade.setText(
            _t(L, "2) DISEGNA AREA E SCARICA PARTICELLE (Shift+Trascina)",
               "2) DRAW AREA AND DOWNLOAD PARCELS (Shift+Drag)")
        )
        self.btn_annulla.setText(_t(L, "Annulla download", "Cancel download"))

        # --- Info
        self.info_browser.setHtml(self._info_html())
        self.family_widget.set_lang(L)

    def _info_html(self):
        L = self.lang
        title = _t(L, "NoRats — Derattizzazione su base GIS", "NoRats — GIS-based rat control")
        sources_title = _t(L, "Fonti dei dati e licenze", "Data sources and licenses")
        intro = _t(
            L,
            "Un'unica finestra, tre schede. <b>Campagna</b>: postazioni esca "
            "con semaforo di ispezione, registro ispezioni con maschere "
            "guidate, report HTML, esportazione PostgreSQL/PostGIS. "
            "<b>Dati territoriali</b> in due fasi: fase 1 scarica il limite "
            "(🇮🇹 ISTAT per i comuni italiani; 🌍 OSM/Nominatim o 📁 un tuo "
            "dataset per l'estero) e le strade OSM; fase 2, con "
            "<b>Shift+Trascina</b>, l'area delle particelle catastali AdE — "
            "sempre ritagliate sul limite.",
            "One window, three tabs. <b>Campaign</b>: bait stations with "
            "inspection traffic-light, guided inspection forms, HTML "
            "reports, PostgreSQL/PostGIS export. <b>Territorial data</b> in "
            "two steps: step 1 downloads the boundary (🇮🇹 ISTAT for "
            "Italian municipalities; 🌍 OSM/Nominatim or 📁 your own "
            "dataset abroad) and the OSM roads; step 2, with "
            "<b>Shift+Drag</b>, the AdE cadastral parcels area — always "
            "clipped on the boundary.",
        )
        istat_label = _t(L, "Confini amministrativi", "Administrative boundaries")
        ade_label = _t(
            L,
            "Particelle catastali (WFS INSPIRE CP:CadastralParcel)",
            "Cadastral parcels (INSPIRE WFS CP:CadastralParcel)",
        )
        osm_label = _t(
            L,
            "Strade (Overpass) e confini (Nominatim)",
            "Roads (Overpass) and boundaries (Nominatim)",
        )
        parcels_note_title = _t(L, "Nota sulle particelle", "Note on the parcels")
        parcels_note = _t(
            L,
            "i poligoni catastali vengono salvati volutamente "
            "<b>muti</b>: nessun attributo, nessuna etichetta, nessun colore "
            "o simbolo dell'Agenzia delle Entrate — solo geometrie neutre da "
            "usare come base di lavoro.",
            "cadastral polygons are deliberately saved <b>mute</b>: no "
            "attributes, no labels, no Revenue Agency colors or symbols — "
            "just neutral geometries to be used as a working base.",
        )
        wfs_credit = _t(
            L,
            "La logica di accesso al WFS AdE (tile da 4 km², pausa tra le "
            "chiamate, deduplica) prende a riferimento il plugin «WFS "
            "Catasto - download particelle bbox» di Salvatore Fiandaca (GPL).",
            "The AdE WFS access logic (4 km² tiles, pause between calls, "
            "deduplication) takes as reference the plugin “WFS Catasto - "
            "download particelle bbox” by Salvatore Fiandaca (GPL).",
        )
        dev_label = _t(L, "Sviluppo", "Development")
        license_line = _t(L, "Licenza GPL v2 o successiva.", "License GPL v2 or later.")

        return f"""
        <body style="color:#f2f5f8; background-color:#141a22;">
        <h2 style="color:#5b9bd5;">{title}</h2>
        <p style="color:#c3ccd6;">{intro}</p>
        <h2 style="color:#5b9bd5;">{sources_title}</h2>
        <table style="color:#c3ccd6;" cellpadding="4">
        <tr><td><b>ISTAT</b></td>
            <td>{istat_label} {downloads.ISTAT_YEAR}</td>
            <td><a style="color:#8ab4e0;" href="https://www.istat.it/it/archivio/222527">CC BY 4.0</a></td></tr>
        <tr><td><b>{_t(L, "Agenzia delle Entrate", "Italian Revenue Agency")}</b></td>
            <td>{ade_label}</td>
            <td><a style="color:#8ab4e0;"
            href="https://www.agenziaentrate.gov.it/portale/cartografia-catastale-wfs">CC BY 4.0</a></td></tr>
        <tr><td><b>OpenStreetMap</b></td>
            <td>{osm_label}</td>
            <td><a style="color:#8ab4e0;" href="https://www.openstreetmap.org/copyright">ODbL</a></td></tr>
        </table>
        <p style="color:#f59e0b;"><b>{parcels_note_title}:</b> {parcels_note}</p>
        <p style="font-size:small; color:#8a97a5;">{wfs_credit}</p>
        <hr style="border:1px solid #2c3a48;">
        <p style="color:#c3ccd6;"><b>{dev_label}:</b>
        {plugin_hub.AUTHOR_NAME} —
        <a style="color:#8ab4e0;" href="mailto:{plugin_hub.AUTHOR_EMAIL}">{plugin_hub.AUTHOR_EMAIL}</a>
        — <a style="color:#8ab4e0;" href="{plugin_hub.AUTHOR_WEBSITE}">sinocloud.it</a></p>
        <p style="font-size:small; color:#8a97a5;">{license_line}</p>
        </body>
        """

    # --------------------------------------------------------------- azioni

    def _browse_output(self):
        path, _ = QFileDialog.getSaveFileName(
            self,
            _t(self.lang, "GeoPackage di destinazione", "Destination GeoPackage"),
            self.edit_output.text() or os.path.expanduser("~"),
            "GeoPackage (*.gpkg)",
        )
        if path:
            if not path.lower().endswith(".gpkg"):
                path += ".gpkg"
            self.edit_output.setText(path)

    def _log(self, message):
        self.txt_console.appendPlainText(message)

    def _start_download(self):
        source = self.combo_source.currentData()
        if source == SOURCE_FILE:
            place_or_path = self.edit_boundary_file.text().strip()
            if not place_or_path or not os.path.exists(place_or_path):
                QMessageBox.warning(
                    self, "NoRats",
                    _t(self.lang, "Scegli un file poligonale esistente.",
                       "Pick an existing polygon file."),
                )
                return
            base_name = os.path.splitext(os.path.basename(place_or_path))[0]
        else:
            place_or_path = self.edit_comune.text().strip()
            if not place_or_path:
                QMessageBox.warning(
                    self, "NoRats",
                    _t(self.lang, "Scrivi il nome del comune / della località.",
                       "Type the municipality / place name."),
                )
                return
            base_name = place_or_path
        output = self.edit_output.text().strip()
        if not output:
            safe = "".join(c if c.isalnum() else "_" for c in base_name.lower())
            output = os.path.join(os.path.expanduser("~"), f"norats_{safe}.gpkg")
            self.edit_output.setText(output)

        cache_dir = os.path.join(
            QgsApplication.qgisSettingsDirPath(), "NoRats", "cache"
        )
        self.task = DownloadTask(
            source,
            place_or_path,
            self.crs_widget.crs(),
            output,
            self.chk_roads.isChecked(),
            cache_dir,
        )
        self.task.message.connect(self._log)
        self.task.progressChanged.connect(
            lambda value: self.progress.setValue(int(value))
        )
        self.task.on_done = self._download_finished
        self.btn_scarica.setEnabled(False)
        self.btn_ade.setEnabled(False)
        self.btn_annulla.setVisible(True)
        self._log(_t(self.lang, f"Avvio download per '{base_name}'...",
                     f"Starting download for '{base_name}'..."))
        QgsApplication.taskManager().addTask(self.task)

    def _cancel_download(self):
        for task in (self.task, self.ade_task):
            if task is not None:
                task.cancel()

    def _download_finished(self, ok, task):
        self.btn_scarica.setEnabled(True)
        self.btn_annulla.setVisible(False)
        if not ok:
            message = task.error or _t(
                self.lang, "Download annullato.", "Download canceled."
            )
            self._log("ERRORE: " + message)
            QMessageBox.critical(self, "NoRats", message)
            return
        self._campaign = (
            task.boundary, task.boundary_crs, task.target_crs, task.gpkg_path
        )
        self.btn_ade.setEnabled(True)
        self._log(
            _t(
                self.lang,
                f"Fase 1 completata: {task.official_name} — limite"
                + (f" e {task.n_roads} strade." if task.want_roads else ".")
                + " Ora puoi disegnare l'area per le particelle AdE.",
                f"Step 1 done: {task.official_name} — boundary"
                + (f" and {task.n_roads} roads." if task.want_roads else ".")
                + " You can now draw the area for the AdE parcels.",
            )
        )
        self._load_layers(
            task.gpkg_path,
            [(downloads.LAYER_ROADS, styles.apply_road_style, task.want_roads),
             (downloads.LAYER_BOUNDARY, styles.apply_boundary_style, True)],
            zoom_to=downloads.LAYER_BOUNDARY,
        )

    # ------------------------------------------------------ fase 2: AdE

    def _start_ade_area(self):
        if self._campaign is None or self.iface is None:
            return
        canvas = self.iface.mapCanvas()
        self.area_tool = ShiftDragAreaTool(canvas, self._on_area_drawn)
        canvas.setMapTool(self.area_tool)
        hint = _t(
            self.lang,
            "Tieni premuto Shift e trascina sulla mappa per disegnare "
            "l'area delle particelle AdE.",
            "Hold Shift and drag on the map to draw the AdE parcels area.",
        )
        self._log(hint)
        self.iface.messageBar().pushInfo("NoRats", hint)
        self.showMinimized()

    def _on_area_drawn(self, rect):
        canvas = self.iface.mapCanvas()
        canvas.unsetMapTool(self.area_tool)
        self.showNormal()
        self.raise_()
        boundary, boundary_crs, target_crs, gpkg_path = self._campaign
        self.ade_task = AdeTask(
            boundary,
            boundary_crs,
            target_crs,
            gpkg_path,
            QgsGeometry.fromRect(rect),
            canvas.mapSettings().destinationCrs(),
        )
        self.ade_task.message.connect(self._log)
        self.ade_task.progressChanged.connect(
            lambda value: self.progress.setValue(int(value))
        )
        self.ade_task.on_done = self._ade_finished
        self.btn_ade.setEnabled(False)
        self.btn_annulla.setVisible(True)
        QgsApplication.taskManager().addTask(self.ade_task)

    def _ade_finished(self, ok, task):
        self.btn_ade.setEnabled(True)
        self.btn_annulla.setVisible(False)
        if not ok:
            message = task.error or _t(
                self.lang, "Download annullato.", "Download canceled."
            )
            self._log("ERRORE: " + message)
            QMessageBox.critical(self, "NoRats", message)
            return
        self._log(
            _t(
                self.lang,
                f"Fase 2 completata: {task.n_parcels} particelle mute "
                "scaricate e ritagliate.",
                f"Step 2 done: {task.n_parcels} mute parcels downloaded "
                "and clipped.",
            )
        )
        self._load_layers(
            task.gpkg_path,
            [(downloads.LAYER_PARCELS, styles.apply_parcel_style, True)],
        )

    # ----------------------------------------------------- caricamento

    def _load_layers(self, gpkg_path, entries, zoom_to=None):
        project = QgsProject.instance()
        zoom_layer = None
        for layer_name, style_fn, wanted_flag in entries:
            if not wanted_flag:
                continue
            # rimuove l'eventuale versione precedente dello stesso layer
            # nello stesso GeoPackage (non tocca layer di altri progetti/gpkg
            # che condividono per caso lo stesso nome layer)
            previous_source = f"{gpkg_path}|layername={layer_name}"
            for existing in list(project.mapLayers().values()):
                if existing.source() == previous_source:
                    project.removeMapLayer(existing.id())
            layer = QgsVectorLayer(
                f"{gpkg_path}|layername={layer_name}", layer_name, "ogr"
            )
            if not layer.isValid():
                continue
            project.addMapLayer(layer)
            style_fn(layer)
            if layer_name == zoom_to:
                zoom_layer = layer

        if zoom_layer is not None and self.iface is not None:
            canvas = self.iface.mapCanvas()
            extent = canvas.mapSettings().layerExtentToOutputExtent(
                zoom_layer, zoom_layer.extent()
            )
            canvas.setExtent(extent.buffered(extent.width() * 0.05))
            canvas.refresh()
