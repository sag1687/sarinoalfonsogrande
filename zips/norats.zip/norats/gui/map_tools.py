"""Strumenti mappa di NoRats."""
from qgis.core import (
    QgsCoordinateTransform,
    QgsGeometry,
    QgsProject,
    QgsRectangle,
    QgsWkbTypes,
)
from qgis.gui import QgsMapTool, QgsMapToolEmitPoint, QgsRubberBand
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor


class ShiftDragAreaTool(QgsMapTool):
    """Selezione di un'area con Shift+Trascina (stesso gesto di Q-Press).

    Al rilascio richiama ``callback(QgsRectangle)`` con il rettangolo nel
    CRS del canvas. Senza Shift il mouse resta libero per la navigazione.
    """

    def __init__(self, canvas, callback):
        super().__init__(canvas)
        self._canvas = canvas
        self._callback = callback
        self._start_point = None
        self._dragging = False
        self._rubber_band = None

    def _band(self):
        if self._rubber_band is None:
            band = QgsRubberBand(self._canvas, QgsWkbTypes.GeometryType.PolygonGeometry)
            band.setColor(QColor(91, 155, 213, 60))       # #5b9bd5 famiglia
            band.setStrokeColor(QColor(91, 155, 213, 220))
            band.setWidth(2)
            self._rubber_band = band
        return self._rubber_band

    def canvasPressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton and (
            event.modifiers() & Qt.KeyboardModifier.ShiftModifier
        ):
            self._dragging = True
            self._start_point = self.toMapCoordinates(event.pos())
            self._band().reset(QgsWkbTypes.GeometryType.PolygonGeometry)

    def canvasMoveEvent(self, event):
        if self._dragging and self._start_point is not None:
            rect = QgsRectangle(
                self._start_point, self.toMapCoordinates(event.pos())
            )
            self._band().setToGeometry(QgsGeometry.fromRect(rect), None)

    def canvasReleaseEvent(self, event):
        if not self._dragging:
            return
        self._dragging = False
        rect = QgsRectangle(
            self._start_point, self.toMapCoordinates(event.pos())
        )
        self.clear()
        if rect.width() > 0 and rect.height() > 0:
            self._callback(rect)

    def clear(self):
        if self._rubber_band is not None:
            self._canvas.scene().removeItem(self._rubber_band)
            self._rubber_band = None

    def deactivate(self):
        self.clear()
        super().deactivate()


class AddStationTool(QgsMapToolEmitPoint):
    """Al clic sulla mappa richiama la callback con il punto già riproiettato
    nel CRS del layer delle postazioni."""

    def __init__(self, canvas, stations_layer, callback):
        super().__init__(canvas)
        self._canvas = canvas
        self._stations_layer = stations_layer
        self._callback = callback
        self.canvasClicked.connect(self._on_click)

    def _on_click(self, point, button):
        transform = QgsCoordinateTransform(
            self._canvas.mapSettings().destinationCrs(),
            self._stations_layer.crs(),
            QgsProject.instance(),
        )
        layer_point = transform.transform(point)
        self._callback(QgsGeometry.fromPointXY(layer_point))
