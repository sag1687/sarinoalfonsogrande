"""Componenti di interfaccia di NoRats: finestre di dialogo e strumenti mappa."""
