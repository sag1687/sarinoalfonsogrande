"""Finestra di registrazione di un'ispezione su una postazione esca."""
from qgis.PyQt.QtCore import QDate
from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDateEdit,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QLineEdit,
    QPlainTextEdit,
    QSpinBox,
)

from .. import plugin_hub


class InspectionDialog(QDialog):
    def __init__(self, station_codes: list, parent=None):
        super().__init__(parent)
        self.setWindowTitle("NoRats — Registra ispezione")
        self.setMinimumWidth(420)
        self.setStyleSheet(plugin_hub.FAMILY_STYLE)

        self.station_combo = QComboBox()
        self.station_combo.addItems(station_codes)

        self.date_edit = QDateEdit(QDate.currentDate())
        self.date_edit.setCalendarPopup(True)
        self.date_edit.setDisplayFormat("dd/MM/yyyy")

        self.consumption_spin = QSpinBox()
        self.consumption_spin.setRange(0, 100)
        self.consumption_spin.setSuffix(" %")
        self.consumption_spin.setToolTip(
            "Percentuale di esca consumata: indicatore dell'attività dei roditori"
        )

        self.replaced_check = QCheckBox("Esca sostituita durante l'ispezione")

        self.operator_edit = QLineEdit()
        self.operator_edit.setPlaceholderText("Nome dell'operatore")

        self.notes_edit = QPlainTextEdit()
        self.notes_edit.setFixedHeight(70)

        layout = QFormLayout(self)
        layout.addRow("Postazione:", self.station_combo)
        layout.addRow("Data ispezione:", self.date_edit)
        layout.addRow("Consumo esca:", self.consumption_spin)
        layout.addRow("", self.replaced_check)
        layout.addRow("Operatore:", self.operator_edit)
        layout.addRow("Note:", self.notes_edit)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel,
            parent=self,
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)

    def values(self) -> dict:
        return {
            "station_code": self.station_combo.currentText(),
            "insp_date": self.date_edit.date(),
            "consumption_pct": self.consumption_spin.value(),
            "bait_replaced": self.replaced_check.isChecked(),
            "operator": self.operator_edit.text(),
            "notes": self.notes_edit.toPlainText(),
        }
