# 🐀🚫 NoRats for QGIS

[![QGIS Version](https://img.shields.io/badge/QGIS-3.28%2B-589632?logo=qgis&logoColor=white)](https://qgis.org/)
[![License: GPL v2](https://img.shields.io/badge/License-GPL%20v2-blue.svg)](https://www.gnu.org/licenses/old-licenses/gpl-2.0.en.html)
[![PyQt5 / PyQt6](https://img.shields.io/badge/Qt-PyQt5%20%7C%20PyQt6-41cd52?logo=qt&logoColor=white)](https://www.riverbankcomputing.com/software/pyqt/)
[![Version: 1.2.0](https://img.shields.io/badge/Version-1.2.0-blue.svg)]()

> **IT** · Gestione completa delle campagne di **derattizzazione** su base GIS, in un'**unica finestra** con tre schede: postazioni esca con semaforo di ispezione e **maschere di inserimento guidate**, registro ispezioni, avvistamenti, aree a rischio, report HTML ed **esportazione su PostgreSQL/PostGIS**. Scarica inoltre i **dati territoriali** dell'area di lavoro — limite (🇮🇹 ISTAT, 🌍 OpenStreetMap o 📁 un dataset tuo), particelle catastali dell'**Agenzia delle Entrate** come poligoni muti (con **Shift+Trascina** per scegliere l'area) e strade **OpenStreetMap**.
>
> **EN** · Complete GIS-based **rat-control** campaign management in a **single window** with three tabs: bait stations with inspection traffic-light and **guided attribute forms**, inspection log, sightings, risk areas, HTML reports and **PostgreSQL/PostGIS export**. It also downloads the working area's **territorial data** — boundary (🇮🇹 ISTAT, 🌍 OpenStreetMap or 📁 your own dataset), Italian Revenue Agency (**AdE**) cadastral parcels as mute polygons (with **Shift+Drag** to pick the area) and **OpenStreetMap** roads.

**🌐 Lingua / Language:** [🇮🇹 Italiano](#-italiano) · [🇬🇧 English](#-english)

---

## 📸 Screenshot

| Progetto di esempio / Sample project | Dati territoriali scaricati / Downloaded territorial data |
|---|---|
| ![Campagna](sample_project/anteprima_mappa.png) | ![Dati](sample_project/anteprima_dati_territoriali.png) |

> **IT** · A sinistra la campagna demo (postazioni a semaforo, avvistamenti, aree a rischio); a destra il download reale di Mandatoriccio (CS): limite ISTAT in blu, 9.404 particelle AdE mute e 390 strade OSM, tutto ritagliato sul confine comunale. · **EN** · On the left the demo campaign (traffic-light stations, sightings, risk areas); on the right the real download of Mandatoriccio (CS): ISTAT boundary in blue, 9,404 mute AdE parcels and 390 OSM roads, everything clipped on the municipal boundary.

## 🇮🇹 Italiano

### Cos'è (in parole semplici)

NoRats è un **registro digitale su mappa** della lotta ai roditori, tutto in un'unica finestra con tre schede. Ogni scatola con l'esca è un punto con un codice (BS-001, BS-002…) il cui colore dice come sta: **verde** controllata da poco, **arancione** da controllare, **rosso** dimenticata da più di un mese o mai controllata. L'inserimento dei dati è guidato da maschere con tendine, calendari e slider, così non si sbaglia a scrivere. Con un clic si produce un report da consegnare al Comune, oppure si esporta tutto su un database PostgreSQL/PostGIS. E se ti servono le basi cartografiche del tuo comune — confine, particelle, strade — le scarichi scrivendo solo il nome del paese.

### ✨ Funzionalità

| | Funzionalità | Descrizione |
|---|---|---|
| 🪟 | **Un'unica finestra** | Una sola icona in toolbar apre le tre schede: Campagna, Dati territoriali, Informazioni. |
| 📍 | **Postazioni esca georiferite** | Clic sulla mappa, codice progressivo automatico, tipo esca, ubicazione. |
| 🚦 | **Semaforo di ispezione** | Simbologia automatica sui giorni dall'ultima ispezione (soglie 15/30 gg). |
| 📋 | **Registro ispezioni** | Storico completo: consumo esca %, sostituzione, operatore, note. |
| 🧾 | **Maschere di inserimento guidate** | Tendine con i soli valori ammessi, calendari, slider percentuale, caselle di spunta e alias leggibili su ogni layer — niente errori di battitura. |
| 👁️ | **Avvistamenti** | Segnalazioni dei cittadini come punti con specie, data ed esemplari. |
| ⚠️ | **Aree a rischio** | Aree private abbandonate, isole ecologiche, rete fognaria con livello 1–3. |
| 📊 | **Report HTML** | Postazioni in ritardo, consumo medio, avvistamenti 30 gg, aree non trattate. |
| 🐘 | **Esportazione PostgreSQL/PostGIS** | Un clic per esportare tutti i layer della campagna su un database, usando le connessioni PostgreSQL già salvate in QGIS. |
| 🗺️ | **Limite dell'area di lavoro** | 🇮🇹 ISTAT per i comuni italiani (con **scelta del CRS**, cache locale), 🌍 OpenStreetMap/Nominatim in tutto il mondo, oppure 📁 un dataset poligonale tuo. |
| 🏛️ | **Particelle catastali AdE** | WFS INSPIRE `CP:CadastralParcel` a tile ≤ 4 km², con **Shift+Trascina** per scegliere l'area (fase 2), deduplicate e **ritagliate sul limite**. Poligoni **muti**: nessun attributo, etichetta, colore o simbolo dell'Agenzia. |
| 🛣️ | **Strade OpenStreetMap** | Tutte le strade dell'area via Overpass API, ritagliate esattamente sul confine. |
| 📦 | **Output GeoPackage** | Tutti i layer nel CRS scelto, in un unico GeoPackage. |
| 🌐 | **Interfaccia bilingue IT/EN** | Pulsante bandiera 🇮🇹/🇬🇧; cambiando lingua cambia anche la fonte suggerita del limite (IT→ISTAT, EN→OSM). |
| 🎨 | **Tema scuro "slate blue"** | Tema condiviso della famiglia di plugin SinoCloud. |
| 🔗 | **Scheda Info con menù a tendina** | Elenco degli altri plugin dell'autore con apertura del repository GitHub. |

### 🚀 Come funziona

1. Apri **NoRats** dall'unica icona in toolbar: si apre la finestra con tre schede.
2. Scheda **Campagna** → **Nuova campagna**: crea il GeoPackage con i quattro layer già tematizzati e con le maschere di inserimento configurate.
3. **Aggiungi postazione esca**: clic sulla mappa → compila la maschera guidata (codice automatico).
4. **Registra ispezione**: scegli la postazione, indica il consumo esca da uno slider; il semaforo si aggiorna da solo.
5. **Genera report HTML**: il riepilogo per l'amministrazione si apre nel browser. Oppure **Esporta campagna su PostgreSQL** per portare tutto a database.
6. Scheda **Dati territoriali**, in due fasi: fase 1 scegli la fonte del limite (🇮🇹 ISTAT / 🌍 OSM / 📁 dataset tuo), scrivi il nome del comune o scegli il file, e premi **1) SCARICA LIMITI E STRADE**. Fase 2, con **Shift+Trascina** sulla mappa, disegni l'area di cui vuoi le particelle catastali AdE e premi **2) DISEGNA AREA E SCARICA PARTICELLE** — sempre ritagliate sul limite scelto in fase 1.

### 🗃️ Modello dati (GeoPackage)

| Layer | Geometria | Contenuto |
|---|---|---|
| `bait_stations` | Punto | postazioni esca; `last_inspection` e `last_consumption` denormalizzati per il semaforo |
| `inspections` | tabella | storico ispezioni (`station_code` → `bait_stations.code`) |
| `sightings` | Punto | avvistamenti (data, specie, esemplari, segnalante) |
| `risk_areas` | Poligono | aree a rischio, `risk_level` 1–3, `last_treatment` |
| `limite_comunale_istat` | MultiPoligono | confine ISTAT con codici ufficiali |
| `particelle_catastali_ade` | MultiPoligono | particelle mute (solo geometria) |
| `strade_osm` | MultiLinea | strade con `name` e `highway` |

### 📥 Installazione

```bash
git clone https://github.com/sag1687/norats.git
cp -r norats ~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/norats
```

Poi attivalo da **Plugin → Gestisci e installa plugin**. Richiede QGIS ≥ 3.28 (compatibile anche con QGIS 4/Qt6); nessuna dipendenza esterna (solo PyQGIS e librerie standard).

### 🧪 Progetto di esempio

In `sample_project/` trovi una campagna demo su Mandatoriccio (CS): `NoRats_Mandatoriccio.qgs` con GeoPackage, stili, sfondo OSM e report già generato. Per rigenerarlo:

```bash
python3 tools/build_sample_project.py   # con il Python di QGIS
```

### ⚠️ Avvertenze e limitazioni

1. **Servizio WFS AdE**: massimo ~4 km² per richiesta; il plugin piastrella il territorio e attende 1,5 s tra le chiamate per cortesia verso il server. Comuni estesi = molte tile = tempi lunghi (Mandatoriccio, 36 km²: 18 tile, 1–5 minuti).
2. **Particelle mute per scelta**: niente attributi catastali, niente vestizione ufficiale. Per i dati catastali completi usa i canali ufficiali AdE.
3. **Ritaglio**: le particelle interamente interne restano intere; quelle a cavallo del confine vengono tagliate sul limite ISTAT (generalizzato, non a valore probatorio).
4. **Confini ISTAT generalizzati**: adatti ad analisi e cartografia tematica, non a delimitazioni legali.
5. **Overpass API**: servizio pubblico con rate-limit; in caso di errore riprova dopo qualche minuto.

### 📜 Fonti dei dati e licenze

| Fonte | Dato | Licenza |
|---|---|---|
| [ISTAT](https://www.istat.it/it/archivio/222527) | Confini amministrativi 2025 (generalizzati) | CC BY 4.0 |
| [Agenzia delle Entrate](https://www.agenziaentrate.gov.it/portale/cartografia-catastale-wfs) | Particelle catastali (WFS INSPIRE) | CC BY 4.0 |
| [OpenStreetMap](https://www.openstreetmap.org/copyright) | Strade (Overpass API) | ODbL |

La logica di accesso al WFS AdE prende a riferimento il plugin [«WFS Catasto - download particelle bbox»](https://plugins.qgis.org/plugins/wfs_catasto_download_particelle_bbox/) di **Salvatore Fiandaca** (GPL).

---

## 🇬🇧 English

### What it is

NoRats is a **map-based digital register** for rodent control, all in a single window with three tabs. Every bait box is a coded point (BS-001, BS-002…) whose color tells its state: **green** recently checked, **orange** due, **red** overdue for more than a month or never inspected. Data entry is guided by forms with dropdowns, calendars and sliders, so nothing gets mistyped. One click produces an HTML report for the municipality, or exports everything to a PostgreSQL/PostGIS database. If you need the cartographic bases of your working area — boundary, parcels, roads — you download them by simply typing the place name.

### ✨ Features

| | Feature | Description |
|---|---|---|
| 🪟 | **A single window** | One toolbar icon opens the three tabs: Campaign, Territorial data, Information. |
| 📍 | **Georeferenced bait stations** | Map click, automatic progressive code, bait type, location. |
| 🚦 | **Inspection traffic-light** | Automatic symbology on days since last inspection (15/30-day thresholds). |
| 📋 | **Inspection log** | Full history: bait consumption %, replacement, operator, notes. |
| 🧾 | **Guided attribute forms** | Dropdowns with the allowed values only, calendars, percentage sliders, checkboxes and readable aliases on every layer — no typos. |
| 👁️ | **Sightings** | Citizens' reports as points with species, date and count. |
| ⚠️ | **Risk areas** | Abandoned private areas, waste collection points, sewer network, level 1–3. |
| 📊 | **HTML reports** | Overdue stations, average consumption, 30-day sightings, untreated areas. |
| 🐘 | **PostgreSQL/PostGIS export** | One click to export every campaign layer to a database, using the PostgreSQL connections already saved in QGIS. |
| 🗺️ | **Working-area boundary** | 🇮🇹 ISTAT for Italian municipalities (with **CRS choice**, local cache), 🌍 OpenStreetMap/Nominatim worldwide, or 📁 your own polygon dataset. |
| 🏛️ | **AdE cadastral parcels** | INSPIRE WFS `CP:CadastralParcel` in ≤ 4 km² tiles, with **Shift+Drag** to pick the area (step 2), deduplicated and **clipped on the boundary**. **Mute** polygons: no attributes, labels, Agency colors or symbols. |
| 🛣️ | **OpenStreetMap roads** | Every road of the area via Overpass API, clipped exactly on the boundary. |
| 📦 | **GeoPackage output** | All layers in the chosen CRS, in a single GeoPackage. |
| 🌐 | **Bilingual IT/EN interface** | Flag button 🇮🇹/🇬🇧; switching language also switches the suggested boundary source (IT→ISTAT, EN→OSM). |
| 🎨 | **"Slate blue" dark theme** | Shared theme of the SinoCloud plugin family. |
| 🔗 | **Info tab with drop-down** | List of the author's other plugins with direct GitHub access. |

### 🚀 How it works

1. Open **NoRats** from the single toolbar icon: the three-tab window opens.
2. **Campaign** tab → **New campaign**: creates the GeoPackage with the four styled layers, forms already configured.
3. **Add bait station**: click the map → fill the guided form (automatic code).
4. **Record inspection**: pick the station, set the bait consumption with a slider; the traffic-light updates itself.
5. **Generate HTML report**: the summary for the administration opens in the browser. Or **Export campaign to PostgreSQL** to push everything to a database.
6. **Territorial data** tab, in two steps: step 1 pick the boundary source (🇮🇹 ISTAT / 🌍 OSM / 📁 your dataset), type the municipality name or pick the file, press **1) DOWNLOAD BOUNDARY AND ROADS**. Step 2, with **Shift+Drag** on the map, draw the area whose AdE cadastral parcels you want and press **2) DRAW AREA AND DOWNLOAD PARCELS** — always clipped on the step-1 boundary.

### ⚠️ Warnings and limitations

1. **AdE WFS service**: ~4 km² per request at most; the plugin tiles the territory and waits 1.5 s between calls out of courtesy to the server. Large municipalities = many tiles = long download times.
2. **Parcels are mute by design**: no cadastral attributes, no official styling. For complete cadastral data use the official AdE channels.
3. **Clipping**: parcels entirely inside the boundary stay whole; the ones crossing it are cut on the ISTAT limit (generalized, not legally binding).
4. **Generalized ISTAT boundaries**: suitable for analysis and thematic cartography, not for legal delimitations.
5. **Overpass API**: public rate-limited service; on error, retry after a few minutes.

### 📜 Data sources and licenses

| Source | Data | License |
|---|---|---|
| [ISTAT](https://www.istat.it/it/archivio/222527) | Administrative boundaries 2025 (generalized) | CC BY 4.0 |
| [Italian Revenue Agency](https://www.agenziaentrate.gov.it/portale/cartografia-catastale-wfs) | Cadastral parcels (INSPIRE WFS) | CC BY 4.0 |
| [OpenStreetMap](https://www.openstreetmap.org/copyright) | Roads (Overpass API) | ODbL |

The AdE WFS access logic takes as reference the plugin ["WFS Catasto - download particelle bbox"](https://plugins.qgis.org/plugins/wfs_catasto_download_particelle_bbox/) by **Salvatore Fiandaca** (GPL).

---

## 🏗️ Architettura / Architecture

```
norats/
├── metadata.txt              # metadati QGIS (>= 3.28, compatibile QGIS 4/Qt6)
├── __init__.py                # classFactory
├── plugin.py                  # NoRatsPlugin: toolbar (icona unica), azioni
├── plugin_hub.py               # modulo condiviso famiglia SinoCloud (tema + scheda info)
├── core/                      # logica senza GUI
│   ├── schema.py              # layer, campi, CRS, domini valori
│   ├── datastore.py           # GeoPackage, CRUD, codici progressivi
│   ├── styles.py              # semaforo, aree rischio, stili muti ISTAT/AdE/OSM
│   ├── forms.py               # maschere di inserimento (widget editing QGIS)
│   ├── postgis.py             # esportazione dei layer su PostgreSQL/PostGIS
│   ├── reports.py             # report HTML
│   └── downloads.py           # ISTAT/OSM/file + WFS AdE + Overpass, con progress/cancel
├── gui/
│   ├── main_dialog.py         # finestra unica: schede Campagna / Dati territoriali / Info
│   ├── station_dialog.py      # nuova postazione
│   ├── inspection_dialog.py   # registrazione ispezione
│   └── map_tools.py           # map tool clic-su-mappa + Shift+Trascina area AdE
├── icons/                     # icona NoRats + logo SinoCloud
├── sample_project/            # campagna demo su Mandatoriccio (CS)
├── tools/build_sample_project.py   # rigenera il progetto di esempio
├── LICENSE, AUTHOR.md, changelog.txt, setup.cfg, .gitignore
```

## 👤 Autore / Author

**Dott. Sarino Alfonso Grande** — Analista GIS
📧 [sino.grande@gmail.com](mailto:sino.grande@gmail.com) · 🌐 [sinocloud.it](https://sinocloud.it) · 💻 [github.com/sag1687](https://github.com/sag1687)

## 📄 Licenza / License

GPL v2 or later — see [LICENSE](LICENSE).
