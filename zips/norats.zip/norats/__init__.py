"""NoRats — gestione derattizzazione su base GIS.

Punto di ingresso del plugin per QGIS.
"""


def classFactory(iface):
    from .plugin import NoRatsPlugin
    return NoRatsPlugin(iface)
